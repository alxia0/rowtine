---
rowtine: 1
title: Patron Zip Démo
author: Alexia
sizes: Taille unique
---

## Corps {body}

- Monter 20 mailles.
- Tricoter en jersey sur 10 cm.
