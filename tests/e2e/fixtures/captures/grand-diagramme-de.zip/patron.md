---
rowtine: 1
title: Netztuch
author: Rowtine
sizes: Einheitsgröße
---

## Maschenprobe {gauge}

10 × 10 cm = 18 M. und 26 R. im Spitzenmuster, Nadeln 4 mm.

## Körper {body}

- Schlage 93 Maschen locker an.
- Stricke 4 Reihen kraus rechts.
- Folge dann der Strickschrift, von rechts nach links und von unten nach oben.

## Strickschrift — Tuchkörper {chart}

![Spitzen-Strickschrift für den Körper](img/grille-corps.png)

## Strickschrift — Rand {chart}

![Spitzen-Strickschrift für den Rand](img/grille-bordure.png)

## Fertigstellung {finishing}

- Ketten Sie locker ab.
- Nass spannen und flach trocknen lassen.
