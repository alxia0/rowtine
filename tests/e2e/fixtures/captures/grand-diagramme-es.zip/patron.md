---
rowtine: 1
title: Chal de Malla
author: Rowtine
sizes: Talla única
---

## Muestra {gauge}

10 × 10 cm = 18 p. y 26 vueltas en encaje, agujas de 4 mm.

## Cuerpo {body}

- Monta 93 puntos con holgura.
- Teje 4 vueltas en punto bobo.
- Después sigue el diagrama, de derecha a izquierda y de abajo arriba.

## Diagrama — cuerpo del chal {chart}

![Diagrama de encaje del cuerpo](img/grille-corps.png)

## Diagrama — borde {chart}

![Diagrama de encaje del borde](img/grille-bordure.png)

## Acabado {finishing}

- Cierra con holgura.
- Bloquea en húmedo y seca en plano.
