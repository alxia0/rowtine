---
rowtine: 1
title: Mesh Shawl
author: Rowtine
sizes: One size
---

## Gauge {gauge}

10 × 10 cm = 18 sts and 26 rows in lace, 4 mm needles.

## Body {body}

- Cast on 93 stitches loosely.
- Work 4 rows in garter stitch.
- Then follow the chart, right to left and bottom to top.

## Chart — shawl body {chart}

![Lace chart for the body](img/grille-corps.png)

## Chart — border {chart}

![Lace chart for the border](img/grille-bordure.png)

## Finishing {finishing}

- Bind off loosely.
- Wet block and dry flat.
