---
rowtine: 1
title: Châle Résille
author: Rowtine
sizes: Taille unique
---

## Échantillon {gauge}

10 × 10 cm = 18 m. et 26 rangs en dentelle, aiguilles 4 mm.

## Corps {body}

- Monter 93 mailles souplement.
- Tricoter 4 rangs au point mousse.
- Suivre ensuite le diagramme, de droite à gauche et de bas en haut.

## Grille — corps du châle {chart}

![Diagramme de dentelle du corps](img/grille-corps.png)

## Grille — bordure {chart}

![Diagramme de dentelle de la bordure](img/grille-bordure.png)

## Finitions {finishing}

- Rabattre souplement.
- Bloquer humide et laisser sécher à plat.
