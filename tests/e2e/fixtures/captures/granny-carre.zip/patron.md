---
rowtine: 1
title: Granny carré
---

## Carré granny {chart}

![Granny carré](img/granny.png)
12 m × 5 rangs · forme radial-carré
