# Guide {app}

## L'esprit de {app}

![Écran de bienvenue de {app}](images/fr/00-bienvenue.webp)

*La toute première ouverture : prénom, technique, langue et thème.*

{app} t'aide à garder tous tes projets de tricot et de crochet au même endroit :
ta laine, tes patrons adaptés à ta taille et ta progression. Elle est **gratuite,
libre et fonctionne hors ligne** — tes données restent sur ton téléphone, pas sur
un serveur. Rien n'est jamais perdu par erreur : tout ce que tu supprimes se
retrouve dans une corbeille.

## 1. L'accueil — ton tableau de bord

![L'accueil de {app}](images/fr/01-accueil.webp)

*L'accueil : la tuile « Reprendre » ramène au dernier ouvrage travaillé, les deux compteurs résument l'essentiel, les trois outils sont à portée de pouce.*

En ouvrant l'app, tu retrouves :
- **Ton dernier projet**, avec un bouton **Reprendre** pour repartir directement
  là où tu en étais. C'est bien le dernier projet sur lequel tu as
  **réellement tricoté ou crocheté** (ta dernière séance), pas simplement le
  dernier que tu as modifié — et il t'indique le rang en cours.
- Un **récapitulatif** : combien de projets sont en cours, ton temps passé à
  tricoter ou crocheter cette semaine (avec le détail dans **Statistiques**),
  et ton **budget dépensé** — le total de tout ce que tu as payé pour ta
  laine depuis que tu utilises l'app, dans la devise que tu as choisie. Ce
  chiffre ne redescend jamais tout seul : consommer une pelote ou terminer un
  projet ne le fait pas baisser (seul un nouvel achat le fait monter) ; il ne
  peut baisser que si tu supprimes ou corriges toi-même une ligne d'achat
  dans le bloc « Achats et cadeaux » d'une fiche de laine (point 5). (Si tu as
  plusieurs devises, chacune a son propre total : l'app ne les mélange pas,
  faute de connaître un taux de change.) En touchant ce chiffre, tu ouvres
  l'écran **Dépenses**, décrit au point 5. Cette tuile n'apparaît pas tant
  qu'aucun achat n'a encore été enregistré (par exemple sur une app toute
  neuve).
- Ce chiffre est différent de la **valeur de ton stock**, affichée dans
  l'écran **Stock de laine** (point 5) : celle-là suit ce que tu as
  actuellement dans tes placards et baisse quand tu utilises une pelote. Les
  deux chiffres cohabitent volontairement : l'un raconte ce que tu as
  dépensé, l'autre ce qu'il te reste.
- Tous tes projets, **groupés par statut** (en cours, à faire, en pause, terminé,
  abandonné), avec un bouton pour tout voir ou replier la liste.
- Un accès rapide aux **outils** (calculateur de mailles, compteur libre, aide
  aiguilles/crochet) et au bouton **+ Créer un projet**.

## 2. Tes projets — le cœur de l'app

![Fiche d'un projet, onglet Sections](images/fr/02-fiche-projet.webp)

*La fiche d'un projet : sa progression globale, le bouton « Suivre le patron », puis une tuile par section avec sa propre avancée et sa case « faite ».*

### Créer, modifier, supprimer

Un projet se crée en quelques secondes : nom, technique (tricot ou crochet),
patron associé (ou « Patron libre » si tu n'en utilises pas). Si tu choisis un
patron existant, l'app **préremplit** pour toi les tailles, les aiguilles ou le
crochet, la jauge et le type — tu n'as plus qu'à ajuster. Un projet supprimé n'est **jamais
perdu tout de suite** : tu peux toujours l'annuler juste après, ou le restaurer
plus tard depuis la corbeille (réglages).

### La fiche projet, à onglets

- **Sections** : les étapes de ton ouvrage (devant, dos, manche…), avec un badge
  de statut (à faire / commencé / en cours / terminée) et, quand le patron a un
  diagramme, un aperçu du diagramme associé.
- **Détails** : toutes les infos du projet — technique, tailles, aiguilles ou
  crochet, jauge, dates de début/fin, ta note en étoiles et une note
  personnelle.
- **Galerie** : tes photos du projet, plus les photos d'origine du patron en
  dessous. Tu choisis laquelle sert de **photo de couverture** (par défaut,
  la première photo du patron).
- **Sessions** : l'historique de tes séances de tricot/crochet, avec la durée de
  chacune, et la possibilité d'ajouter une séance
  manuellement (si tu as tricoté sans l'app ouverte).

### Travailler en direct — la séance

Quand tu ouvres une section pour tricoter ou crocheter :
- Un **chrono** t'attend en bas de l'écran. Il **ne se lance pas tout seul** : c'est
  toi qui appuies dessus quand tu commences, et qui le remets en pause pour une
  interruption (le bouton affiche alors **Reprendre** avec le temps déjà compté). Une
  fois lancé, il continue même si tu éteins l'écran, changes d'appli ou redémarres ton
  téléphone — il retrouve toujours le fil.
- Tu **coches les rangs** au fur et à mesure, avec tes instructions affichées
  (jusqu'à 8 lignes visibles, reprise automatique là où tu en étais).
- Tu gères des **compteurs** multiples par projet (mailles, rangs, répétitions…),
  chacun avec un bouton + et − et une correction possible en cas d'erreur de
  frappe.
- Un bouton **Fermer et enregistrer** archive proprement la séance dans l'onglet
  Sessions.

## 3. Le patron qui s'adapte à toi — le lecteur interactif

![Le lecteur : choix de la taille et aide-mémoire](images/fr/03a-lecteur-haut.webp)

*En haut du lecteur : on choisit sa taille une fois, et l'aide-mémoire (matériel, tableau des tailles, techniques, abréviations) reste à portée de main.*

![Le lecteur : diagramme suivi rang par rang](images/fr/03b-lecteur-diagramme.webp)

*Plus bas : le diagramme se suit rang par rang, avec son compteur « Rang du diagramme », son sens de lecture, et le chrono en bas d'écran.*

C'est la fonction phare de {app}. Quand un patron a été mis au format
« lecture guidée » (les 3 patrons d'exemple le sont, ainsi que tout patron
importé et vérifié), tu obtiens :

- **Le sélecteur de taille** : tu choisis ta taille une fois, et **tous les
  chiffres du patron se filtrent automatiquement** pour toi (mailles, rangs,
  longueurs). Fini les notations du genre « 104 (108) 112… » à décoder à chaque
  ligne.
- **Le suivi pas à pas** : chaque étape est cochable, avec une barre de
  progression globale et par section, et des compteurs de répétition intégrés
  (« − 3/12 + ») qui disparaissent tout seuls s'ils ne concernent pas ta taille.
- **Le diagramme interactif** : le diagramme du patron (extrait tel quel du PDF
  d'origine) avec une **bande qui suit le rang en cours**, les rangs déjà faits
  grisés, et un compteur « Rang X sur 52 ». Accessible directement dans la page
  ou via un bouton flottant, et l'état est partagé entre les sections qui
  utilisent le même diagramme.
- **L'aide-mémoire** : les abréviations du patron s'affichent en infobulle dès
  que tu les touches, sans quitter ton rang ; un panneau complet regroupe aussi
  les techniques (avec tutoriels vidéo), le matériel et l'échantillon, le
  tableau des tailles, la liste des abréviations, et les **conseils et astuces**
  donnés par le patron.
- Tu peux consulter un patron en lecture (aperçu depuis la bibliothèque) **ou**
  suivre ta progression réelle depuis un projet — les deux accès existent, et ta
  progression est toujours sauvegardée.

### Le diagramme en plein écran, et comment bien le « caler »

C'est l'opération la plus technique de l'app, donc voici le détail.

Tape sur un diagramme (ou sur le bouton « agrandir » à côté) pour l'ouvrir en
plein écran : tu peux alors zoomer (pincer à deux doigts, double-tap, ou
boutons +/−) et te déplacer dedans pour lire chaque maille, avec les mêmes
boutons de suivi de rang que dans la page.

Le souci que le calage résout : le PDF d'origine a souvent des marges (texte,
espace blanc) autour du quadrillage du diagramme. Sans réglage, l'app ne sait
pas où commence et où finit le quadrillage sur l'image — la bande qui te
montre « tu en es là » risquerait de tomber au mauvais endroit.

![Le mode calage d'un diagramme](images/fr/03c-diagramme-calage.webp)

*Le mode calage : les deux lignes fléchées à faire glisser sur les bords du quadrillage, la consigne, et les trois boutons Réinitialiser / Annuler / Enregistrer.*

**Comment caler un diagramme, la première fois que tu l'ouvres :**

1. En plein écran, dans la barre du haut, appuie sur l'icône **Caler**
   (deux barres horizontales reliées par une flèche verticale) — c'est la
   première icône après le titre, juste avant les boutons de zoom et de
   fermeture ; ce bouton n'a pas de texte, uniquement ce pictogramme.
2. Deux lignes fléchées apparaissent sur l'image, chacune avec une petite
   étiquette (« Haut du quadrillage » / « Bas du quadrillage »). Fais glisser
   chacune pour l'amener **exactement sur le bord du quadrillage** : la ligne
   « Bas du quadrillage » sur le tout **premier rang** du diagramme, celle
   « Haut du quadrillage » sur le tout **dernier**. (Ni sur le texte ou les
   marges autour, ni sur le bord de la photo elle-même — sur le quadrillage
   seul.)
3. Pendant que tu ajustes, une bande de repère reste affichée sur ton rang
   en cours : sers-t'en pour vérifier en direct que ça tombe juste, avant de
   valider.
4. Appuie sur **Enregistrer**. (« Annuler » abandonne le réglage en cours ;
   « Réinitialiser » retire le calage existant et repart de l'image entière.)

Une fois calé, le suivi de rang reste précis pour toute la suite de ton
ouvrage sur ce diagramme, dans **ce projet-là**. À savoir : le calage est
mémorisé avec ta progression sur le projet, pas avec le patron lui-même — si
tu commences un deuxième projet à partir du même patron, il te faudra le
refaire une fois pour ce nouveau projet (l'opération ne prend que quelques
secondes).

**Suivre ta position dans une ligne longue.**

![La manette de progression sur le rang en cours](images/fr/03d-diagramme-rideau.webp)

*La manette ronde, posée sur le rang en cours : à sa droite, la partie du rang déjà faite est teintée. Elle n'existe que sur cette ligne-là.*

Sur un diagramme très large, une fois zoomé, il est facile de perdre le fil de la
maille où tu en es. En plein écran, une **petite manette ronde** apparaît sur le rang
en cours — et sur lui seul, pas sur tout le diagramme. Fais-la glisser de droite à
gauche (ou l'inverse) au fil de tes mailles : la portion du rang qu'elle laisse
derrière elle se teinte, pour représenter ce que tu as déjà tricoté.

Un bouton à côté du compteur de rang inverse le côté teinté (utile quand le rang
suivant se lit dans l'autre sens). La manette revient d'elle-même à sa place à
chaque nouveau rang, et ta position est gardée même si tu quittes l'app. La
première fois que tu ouvres un diagramme, un petit message te signale son
existence, pour ne pas passer à côté.

### Sur tablette : le diagramme à côté du texte

Si tu tricotes sur une tablette tenue à l'horizontale, le lecteur se met tout
seul **en deux colonnes** : tes instructions à gauche, un diagramme affiché en
permanence à droite — plus besoin de faire défiler entre les deux. Tu gardes
la main dessus :

- Sur n'importe quel autre diagramme du patron, le bouton **Afficher à droite**
  le fait passer dans le volet (pratique quand un patron en contient
  plusieurs).
- Le bouton **Ramener dans le texte** referme le volet et remet le diagramme
  à sa place dans le fil, si tu préfères tout lire dans une seule colonne.
- À l'endroit du texte où se trouvait le diagramme, un renvoi te rappelle
  qu'il est **affiché à droite** — rien ne disparaît sans le dire.

Ce réglage ne vaut que le temps de ta consultation : en rouvrant le patron,
tu retrouves le volet avec le premier diagramme. Sur téléphone (ou sur une
tablette tenue à la verticale), le lecteur reste en une seule colonne, comme
avant. Un patron sans diagramme n'a pas de volet du tout.

## 4. Ta bibliothèque de patrons

![La bibliothèque de patrons](images/fr/04-bibliotheque.webp)

*La bibliothèque, avec les trois patrons de démonstration fournis à la première ouverture.*

![Fiche d'un patron](images/fr/04b-fiche-patron.webp)

*La fiche d'un patron, volontairement épurée : créer un projet, ou prévisualiser. (C'est depuis l'aperçu qu'on accède à la correction de l'import.)*

- **Importer un PDF** : dépose le PDF de ton patron, l'app le lit et
  **reconstruit automatiquement** les tailles, les rangs et les sections —
  gratuitement, sans connexion internet et sans rien envoyer nulle part. Un
  écran de relecture te permet de vérifier et corriger le résultat avant de
  l'enregistrer.
- **Retrouver un patron** : les pastilles de catégorie en haut de la
  bibliothèque affichent **le nombre de patrons** de chacune, pour savoir d'un
  coup d'œil où chercher.
- **Corriger un patron** : un éditeur en plein écran te permet de retoucher un
  patron importé (texte, tailles, images) si l'import automatique n'a pas tout
  compris correctement. C'est l'autre opération technique de l'app — détail
  ci-dessous.
- **Vue patron** : consultation en lecture simple pour les patrons sans mise en
  forme spéciale, ou les patrons saisis entièrement à la main.
- **3 patrons d'exemple** sont livrés avec l'app dès le premier lancement, pour
  découvrir toutes les fonctions sans rien importer.

### L'éditeur de correction, en détail

C'est l'opération la plus technique de l'app avec le calage des diagrammes
(ci-dessus) : voici comment elle marche vraiment.

**Le principe.** Ton patron est constitué de lignes de texte, et **chaque
ligne porte une catégorie** qui dit à l'app à quoi elle sert : une case à
cocher pendant le tricot ? un titre de partie ? une simple information de
référence ? L'import automatique attribue déjà une catégorie à chaque ligne
en arrivant — l'éditeur sert à corriger celles qu'il a mal devinées, et à
retoucher le texte si une phrase a été mal coupée.

**Les catégories possibles :**

| Catégorie | Ce que ça donne dans ton projet |
|---|---|
| **Étape** | Une case à cocher pendant le tricot ou le crochet — le cœur du suivi pas à pas. |
| **Compteur** | Une étape répétée, avec son propre compteur. Deux variantes : **Répétition** (refaire la ligne N fois) et **Cadence** (refaire la ligne tous les X rangs, N fois). |
| **Note** | Un texte informatif affiché à cet endroit-là, sans case à cocher. |
| **Section** | Un titre de partie (Devant, Manche, Col…), avec son icône automatique — c'est ce qui découpe ton patron dans l'onglet Sections. |
| **Aide-mémoire** | Une information de la fiche du patron (fil, aiguilles, tailles…) — **pas** du suivi pas à pas. Sept sous-catégories : **Fil** (marque, matière, métrage, quantités), **Aiguilles** (aiguilles ou crochets), **Échantillon** (la mesure de référence, ex. « 10 × 10 cm = 22 mailles »), **Matériel** (le reste : boutons, marqueurs…), **Abréviations** (une par ligne), **Tailles** (le tableau des mesures finales — pas les instructions par taille, qui sont des Sections), **Techniques** (une technique expliquée). Ce sont ces blocs qui remplissent l'aide-mémoire du lecteur interactif (section 3 ci-dessus). |
| **Texte** | Un paragraphe simple, sans rôle particulier. |
| **Image** | Une photo ou un diagramme. |

**Comment changer la catégorie d'une ligne :**

1. Place ton curseur sur la ligne (ou sélectionne plusieurs lignes à la
   fois). La barre d'outils juste au-dessus de l'éditeur affiche en surbrillance
   la catégorie déjà appliquée, pour que tu saches toujours où tu en es.
2. Appuie sur le bouton (Étape, Note, Texte) ou choisis dans le menu
   (Compteur, Section, Aide-mémoire — ces trois-là ont des sous-catégories) qui
   correspond à ce que doit devenir la ligne.
3. La couleur et le rendu de la ligne changent immédiatement pour confirmer.

**Deux façons de voir le texte.** Par défaut, l'éditeur affiche une **vue
enrichie** : les images apparaissent en miniature, les compteurs sous forme de
pastilles, les rangs avec leur case à cocher — un aperçu proche de ce que tu
verras en vrai. Le bouton **Modifier le texte** bascule vers le texte brut (le
balisage devient visible) et ouvre le clavier : utile pour corriger une
formulation, une faute de frappe, ou une phrase que l'import a mal coupée en
deux lignes.

**Réordonner sans couper-coller.** Deux flèches (monter/descendre) déplacent
la ligne où se trouve ton curseur, pratique si l'import a placé une étape ou
un titre de section au mauvais endroit.

**Transformer une photo en diagramme suivi (ou l'inverse).** Un bandeau
« Diagrammes de ce patron », repliable en bas de l'éditeur, liste chaque
section qui contient une image. Pour chacune, un bouton bascule entre
**Image simple** (juste une photo) et **Suivre comme diagramme** (la rend
suivable rang par rang dans le lecteur, avec le calage décrit plus haut) —
pratique si l'import a raté un diagramme, ou si tu veux au contraire qu'une
simple photo reste une simple photo.

**Enregistrer.** Les boutons **Annuler** / **Enregistrer** sont fixés en bas
de l'écran. Si tu essaies de quitter avec des modifications non enregistrées,
l'app t'arrête et te demande confirmation — rien ne se perd par erreur, ici
non plus.

## 5. Ton stock de laine

![Le stock de laines](images/fr/05-stock.webp)

*Le stock : les totaux en tête (pelotes, longueur, poids, valeur), puis une carte par laine avec son état — libre ou réservée par un projet.*

- **Ajouter une pelote** : marque, épaisseur (avec une aide pour comprendre les
  catégories d'épaisseur), composition (choisie dans une liste ; si ta matière
  n'y est pas, « Autre » te laisse la saisir, et elle est ensuite proposée
  comme les autres), couleur (choisie sur une palette, avec un sélecteur de
  teinte personnalisée si besoin), quantité, prix, longueur et poids par
  pelote, plus la date d'achat et le numéro de bain.
  **Dès que tu enregistres, l'app note aussitôt l'achat correspondant** et ton
  budget dépensé (point 1) monte du montant indiqué. La date proposée est celle
  du jour : si tu as acheté cette laine il y a plus longtemps, corrige-la
  directement dans le formulaire. (Ces deux champs n'apparaissent qu'à la
  création. Sur une fiche déjà enregistrée, c'est le bloc **Achats et cadeaux**
  qui prend le relais, avec une ligne par acquisition.)
- **Les laines qui ne sont pas d'une seule couleur** : un champ **Type de
  coloris** (uni, dégradé, auto-rayant, moucheté, teint main) et un champ
  **Description du coloris** (« bleu, vert, jaune moucheté de noir ») complètent
  la pastille de couleur — parce qu'une seule teinte ne suffit pas à décrire une
  laine multicolore. Le type de coloris se retrouve dans la recherche et dans
  l'export tableur.
- **Le récapitulatif** en haut de l'écran : nombre de pelotes, longueur et
  poids cumulés (qui basculent tout seuls en km et en kg quand les totaux
  deviennent importants), et la valeur totale de ton stock.
- **Rechercher et trier** ta laine par marque ou par épaisseur, en liste ou en
  grille visuelle.
- **Modifier, dupliquer ou supprimer** une fiche depuis le menu **Actions**
  (icône verticale à trois points) de sa carte. « Dupliquer » est pratique
  pour la même laine dans un autre coloris :
  tout est repris, tu n'as plus qu'à changer la couleur.
- **Le pool de pelotes** : tu vois d'un coup d'œil, pour chaque laine, combien
  de pelotes sont **réservées** à un projet et combien sont **libres**. Tu ne
  peux pas descendre la quantité en dessous de ce qui est déjà réservé (l'app
  te dit combien de pelotes sont retenues) ; et elle t'avertit si restaurer un
  projet depuis la corbeille remet en cause tes réserves de laine — le projet
  revient quand même, mais avec une réservation réduite et un message qui te
  l'explique.
- **Fiche détail** d'une laine : récapitulatif complet (pelotes, mètres,
  projets qui l'utilisent), et un bloc **Achats et cadeaux** qui garde la
  trace de chaque acquisition de cette laine :
  - Chaque ligne porte une quantité, un prix, une date et un bain de
    teinture, et précise si c'était un **achat** ou un **cadeau** (un cadeau
    ne compte jamais dans ton budget dépensé). Les trois lignes les plus
    récentes sont visibles tout de suite, le reste se déplie d'un geste.
  - Tu peux **ajouter, modifier ou supprimer** une ligne à tout moment.
  - **Augmenter la quantité** d'une laine depuis sa fiche te propose
    d'enregistrer l'achat correspondant, daté du jour : tu peux l'accepter,
    le marquer comme cadeau, ou l'ignorer si tu ne veux pas le garder.
    **Diminuer une quantité, en revanche, ne touche jamais à ton budget** —
    seule une augmentation peut créer un achat.
  - Si le nombre de pelotes de ta fiche ne correspond pas à ce que
    l'historique a enregistré (par exemple après une correction manuelle du
    stock), une alerte te le signale et un bouton **Corriger** te propose les
    deux solutions : ajouter l'achat qui manque, ou ajuster la quantité
    affichée.
  - Un achat garde son libellé même si tu supprimes définitivement la fiche
    de la laine : rien de ce que tu as dépensé ne disparaît, il reste visible
    dans l'écran **Dépenses**.

### L'écran Dépenses

Accessible en touchant le budget dépensé sur l'accueil (point 1), cet écran
récapitule tout ce que tu as payé pour ta laine :
- Le **total dépensé**, par devise si tu en as utilisé plusieurs.
- Un **tri par année** : un menu **Année** en haut de l'écran n'affiche que
  l'année choisie (ou « Toutes les années »), et les totaux se recalculent en
  conséquence. Les achats dont tu n'as pas noté la date se retrouvent sous
  « Date inconnue », qui s'ajoute au menu quand il y en a.
- Une **répartition par année puis par mois**, pour voir où part ton budget
  au fil du temps.
- La **liste complète** de tous tes achats et cadeaux, y compris ceux dont la
  fiche de laine a été supprimée depuis (repérables par la mention « Laine
  supprimée »).
- La possibilité de **supprimer** une ligne directement depuis cet écran, en
  te laissant l'**annuler** juste après si c'était une erreur.

## 6. Outils indépendants

![Le compteur libre](images/fr/06a-compteurs.webp)

*Le compteur libre, utilisable sans projet : on le nomme, et on choisit s'il suit des augmentations/diminutions ou des répétitions.*

![Le calculateur](images/fr/06b-calculateur.webp)

*Le calculateur de mailles : répartir des augmentations ou des diminutions sur un nombre de rangs, ou trouver combien de rangs il faut à une cadence donnée — à plat ou en rond.*

Ces outils fonctionnent sans être liés à un projet précis, accessibles depuis
l'accueil :
- **Calculateur de mailles** : il répond dans les deux sens. Soit tu lui donnes
  un nombre de rangs et il te dit comment y répartir tes augmentations ou tes
  diminutions ; soit tu lui donnes ta cadence (« tous les 4 rangs ») et il te
  dit combien de rangs il te faut pour atteindre ton nombre de mailles cible,
  et à quel rang tombe le dernier changement. Un champ indique combien de
  mailles tu ajoutes ou retires à chaque fois — 1 le plus souvent, 2 pour une
  manche où l'on augmente d'une maille de chaque côté. Quand ta cible n'est pas
  atteignable pile, il te propose les deux possibilités qui l'encadrent plutôt
  que d'arrondir sans le dire. À plat il parle en rangs, en rond en tours.
- **Compteur libre** : un ou plusieurs compteurs indépendants (+/−, objectif à
  atteindre, remise à zéro), pour tout ce qui ne relève pas d'un projet
  enregistré.
- **Trouver ma taille d'aiguilles (ou de crochet)** : tu donnes ce qui est
  écrit sur l'étiquette de ta pelote (taille d'aiguilles conseillée et nombre
  de mailles pour 10 × 10 cm, ou 4 × 4 pouces) puis l'échantillon demandé par
  ton patron, et l'app te dit par quelle taille commencer — une au-dessus, une
  en dessous, ou la même. Elle te prévient aussi quand l'écart est trop grand
  pour être rattrapé (cette laine n'ira pas avec ce patron), et rappelle
  toujours qu'un échantillon reste à tricoter pour vérifier : c'est un point
  de départ, pas une garantie. Le champ des rangs est facultatif.

## 7. Statistiques

![L'écran de statistiques](images/fr/07-statistiques.webp)

*Le temps passé, par semaine, mois ou année. Le total courant repart de zéro chaque lundi ; l'historique, lui, cumule.*

Le temps que tu as passé à tricoter ou crocheter, par semaine et par mois, tous
projets confondus — pour te rendre compte de ta régularité (ou te faire
plaisir en voyant le chemin parcouru).

## 8. Réglages

![Les réglages](images/fr/08-reglages.webp)

*Le haut des réglages : prénom, technique par défaut, thème, langue, unités et devise. Plus bas se trouvent le dossier de sauvegarde et la corbeille.*

- **Profil** : ton prénom (utilisé pour te saluer sur l'accueil) et ta
  technique par défaut (tricot ou crochet).
- **Apparence** : thème clair, sombre, ou aligné sur celui de ton téléphone.
- **Langue** : français, anglais, allemand ou espagnol. Chaque langue est
  écrite dans sa propre langue dans la liste (« Deutsch », « Español »), pour
  que tout le monde retrouve sa langue avec facilité.
- **Unités et devise** :
  - **Métrique** (mètres, grammes) ou **impérial** (yards, onces, livres) —
    tout suit : la saisie de tes pelotes, les totaux du stock, l'échantillon
    (10 × 10 cm ou 4 × 4 pouces). Changer de système ne modifie pas tes
    chiffres enregistrés, il les réaffiche dans l'autre unité.
  - **Devise** parmi cinq (€, $, £, CHF, $ CA). Attention, c'est une simple
    étiquette : les prix déjà saisis **ne sont pas convertis**, ils sont
    affichés avec l'autre symbole — l'app te le rappelle avant de valider.
  - Ces deux réglages te sont proposés **dès le premier écran** à l'ouverture
    de l'app, pré-remplis d'après la langue de ton téléphone ; tu peux les
    changer à tout moment ici.
- **Données** :
  - Export de ton stock, de tes projets ou de tes patrons en tableur (CSV),
    pour les consulter ou les sauvegarder ailleurs. Les colonnes suivent tes
    réglages : longueurs et poids dans ton système d'unités, prix avec le
    symbole de ta devise.
  - **Corbeille** universelle : tout projet, laine ou patron supprimé s'y
    retrouve et peut être restauré à tout moment (jusqu'à vidage volontaire).
- **Dossier {app}** : tu désignes un dossier sur ton téléphone (ou un dossier
  synchronisé) dans lequel l'app **sauvegarde en continu** tout ce que tu fais,
  sous forme de fichiers lisibles — pas besoin de cliquer sur « Sauvegarder ».
  Si tu réinstalles l'app et redésignes ce même dossier, tout revient comme avant.
- **Contribuer** : lien vers le code source (l'app est open source) et vers les
  moyens de la soutenir.

## 9. Sous le capot — ce que {app} te garantit

- **Hors ligne par défaut** : aucune de tes données ne quitte ton téléphone,
  sauf le dossier de sauvegarde que **tu choisis toi-même**.
- **Pas de compte, pas de paywall** : toutes les fonctions ci-dessus sont
  gratuites, sans fonction cœur verrouillée.
- **Rien ne se perd par erreur** : chaque suppression est annulable dans
  l'instant, et retombe de toute façon dans la corbeille.
- **Pensée pour être lisible par tout le monde** : contrastes suffisants,
  boutons assez grands pour être touchés facilement, compatible avec les
  lecteurs d'écran.
- **À l'aise sur tous les écrans** : sur un petit téléphone, rien ne déborde ni
  ne se coupe ; sur une tablette, l'app profite de la place — tes listes de
  projets et de patrons s'affichent sur plusieurs colonnes au lieu d'une seule
  longue pile, et le lecteur peut garder le diagramme à côté du texte. L'app
  tient compte des zones réservées de ton écran (barre d'état, encoche, barre
  de navigation) : le contenu ne se glisse plus dessous.
- **En quatre langues** : français, anglais, allemand et espagnol.
