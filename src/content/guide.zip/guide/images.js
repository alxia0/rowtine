// Résout le nom d'une capture du guide ("00-bienvenue", extrait par le parseur depuis
// `![alt](images/fr/00-bienvenue.webp)`) vers son URL réelle, par langue.
//
// `import.meta.glob` (Vite) résout tout ceci À LA COMPILATION : les fichiers WebP sont
// embarqués dans le paquet, aucune requête réseau ni résolution dynamique au chargement.
// `eager: true` : les 4 (à terme) jeux ne pèsent que quelques centaines de Ko au total
// (mesuré, tâche 2.3) — pas besoin d'un import paresseux par image.
const modules = import.meta.glob('./images/*/*.webp', { eager: true, query: '?url', import: 'default' })

const IMAGES_BY_LANG = {}
for (const [modPath, url] of Object.entries(modules)) {
  const m = /\.\/images\/([a-z]{2})\/([\w-]+)\.webp$/.exec(modPath)
  if (!m) continue
  const [, lang, name] = m
  IMAGES_BY_LANG[lang] ??= {}
  IMAGES_BY_LANG[lang][name] = url
}

export function guideImagesFor(lang) {
  return IMAGES_BY_LANG[lang] ?? {}
}
