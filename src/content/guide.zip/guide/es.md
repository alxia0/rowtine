# Guía de {app}

## El espíritu de {app}

![Pantalla de bienvenida de {app}](images/es/00-bienvenue.webp)

*El primer inicio: nombre, técnica, idioma y tema.*

{app} te ayuda a tener todos tus proyectos de punto y ganchillo en un
solo sitio: tu lana, tus patrones adaptados a tu talla y tu progreso. Es
**gratuita, de código abierto y funciona sin conexión** — tus datos se
quedan en tu teléfono, no en un servidor. Nada se pierde nunca por
error: todo lo que borras acaba en una papelera.

## 1. Inicio — tu panel de control

![El inicio de {app}](images/es/01-accueil.webp)

*Inicio: la ficha «Continuar» te lleva al último proyecto en el que trabajaste, los dos contadores resumen lo esencial y las tres herramientas están a mano.*

Al abrir la app encuentras:
- **Tu último proyecto**, con un botón **Continuar** para retomarlo justo
  donde lo dejaste. Es realmente el proyecto en el que **de verdad
  tejiste o ganchillaste** por última vez (tu última sesión), no
  simplemente el último que modificaste — y te muestra la fila en curso.
- Un **resumen**: cuántos proyectos tienes en curso, el tiempo que has
  dedicado a tejer o ganchillar esta semana (con el detalle en
  **Estadísticas**), y tu **presupuesto gastado** — el total de todo lo
  que has pagado por lana desde que usas la app, en la moneda que
  elegiste. Esta cifra nunca baja sola: usar un ovillo o terminar un
  proyecto no la reduce (solo una compra nueva la aumenta); solo puede
  bajar si tú borras o corriges una línea de compra en el bloque
  «Compras y regalos» de una ficha de lana (punto 5). (Si has usado
  varias monedas, cada una tiene su propio total: la app nunca las
  mezcla, porque no conoce un tipo de cambio.) Al tocar esta cifra abres
  la pantalla **Gastos**, descrita en el punto 5. Esta ficha no aparece
  hasta que hayas registrado al menos una compra (por ejemplo en una
  instalación recién hecha).
- Esta cifra es distinta de tu **valor del stock**, mostrado en la
  pantalla **Stock de lana** (punto 5): ese sigue lo que tienes
  actualmente en el armario y baja cuando usas un ovillo. Las dos cifras
  conviven a propósito: una cuenta lo que has gastado, la otra lo que
  te queda.
- Todos tus proyectos, **agrupados por estado** (en curso, pendiente, en
  pausa, terminado, abandonado), con un botón para verlos todos o
  plegar la lista.
- Acceso rápido a las **herramientas** (calculadora de puntos, contador
  libre, ayuda de agujas o ganchillo) y al botón **+ Crear un proyecto**.

## 2. Tus proyectos — el corazón de la app

![Ficha de un proyecto, pestaña Secciones](images/es/02-fiche-projet.webp)

*La ficha de un proyecto: su progreso global, el botón «Seguir el patrón», y luego una ficha por sección con su propio avance y su casilla de «hecha».*

### Crear, editar, eliminar

Un proyecto se crea en unos segundos: nombre, técnica (punto o
ganchillo), patrón asociado (o «Patrón libre» si no usas ninguno). Si
eliges un patrón existente, la app te **rellena de antemano** las
tallas, las agujas o el ganchillo, la muestra y el tipo — solo te queda
ajustar. Un proyecto eliminado **nunca se pierde de inmediato**: puedes
deshacerlo justo después, o restaurarlo más tarde desde la papelera
(ajustes).

### La ficha de proyecto, por pestañas

- **Secciones**: las etapas de tu pieza (delantero, espalda, manga…),
  con una etiqueta de estado (pendiente / empezada / en curso /
  terminada) y, cuando el patrón tiene un diagrama, una vista previa
  del diagrama correspondiente.
- **Detalles**: toda la información del proyecto — técnica, tallas,
  agujas o ganchillo, muestra, fechas de inicio/fin, tu valoración en
  estrellas y una nota personal.
- **Galería**: tus fotos del proyecto, más las fotos originales del
  patrón debajo. Eliges cuál sirve de **foto de portada** (por defecto,
  la primera foto del patrón).
- **Sesiones**: el historial de tus sesiones de punto o ganchillo, con
  la duración de cada una, y la posibilidad de
  añadir una sesión manualmente (si tejiste sin la app abierta).

### Trabajar en directo — la sesión

Al abrir una sección para tejer o ganchillar:
- Un **cronómetro** te espera en la parte de abajo de la pantalla. **No
  se pone en marcha solo**: lo tocas para empezar, y vuelves a tocarlo
  para pausarlo en una interrupción (el botón muestra entonces
  **Reanudar** con el tiempo ya contado). Una vez en marcha, sigue
  corriendo aunque apagues la pantalla, cambies de app o reinicies el
  teléfono — siempre recupera el hilo.
- Vas **marcando las filas** una a una, con las instrucciones mostradas
  (hasta 8 líneas visibles, con vuelta automática justo donde te
  quedaste).
- Llevas varios **contadores** por proyecto (puntos, filas,
  repeticiones…), cada uno con un botón + y − y una forma de corregir
  un toque equivocado.
- Un botón **Cerrar y guardar** archiva la sesión de forma ordenada en
  la pestaña Sesiones.

## 3. El patrón que se adapta a ti — el lector interactivo

![El lector: elección de talla y guía rápida](images/es/03a-lecteur-haut.webp)

*Arriba del lector: eliges tu talla una vez, y la guía rápida (materiales, tabla de tallas, técnicas, abreviaturas) queda a mano.*

![El lector: diagrama seguido fila a fila](images/es/03b-lecteur-diagramme.webp)

*Más abajo: sigues el diagrama fila a fila, con su propio contador «Fila del diagrama», su sentido de lectura, y el cronómetro al pie de la pantalla.*

Esta es la función estrella de {app}. Cuando un patrón se ha puesto en
formato «lectura guiada» (los 3 patrones de ejemplo ya lo están, igual
que cualquier patrón importado y verificado), te ofrece:

- **El selector de talla**: eliges tu talla una vez, y **todas las
  cifras del patrón se filtran automáticamente** en consecuencia
  (puntos, filas, largos). Se acabó descifrar notaciones como
  «104 (108) 112…» en cada línea.
- **El seguimiento paso a paso**: cada paso lo puedes marcar, con una
  barra de progreso global y por sección, y contadores de repetición
  integrados («− 3/12 +») que desaparecen solos si no corresponden a tu
  talla elegida.
- **El diagrama interactivo**: el diagrama del patrón (extraído tal cual
  del PDF original) con una **banda que sigue tu fila en curso**, las
  filas ya hechas en gris, y un contador «Fila X de 52». Accesible
  directamente en la página o mediante un botón flotante, con su estado
  compartido entre las secciones que usan el mismo diagrama.
- **La guía rápida**: las abreviaturas del patrón aparecen en una
  burbuja en cuanto las tocas, sin que salgas de tu fila en curso; un
  panel completo agrupa además las técnicas (con tutoriales en vídeo),
  los materiales y la muestra, la tabla de tallas, la lista de
  abreviaturas, y los **consejos y trucos** que da el patrón.
- Un patrón lo puedes consultar en modo lectura (vista previa desde la
  biblioteca) **o** seguir tu progreso real desde un proyecto — los dos
  accesos existen, y tu progreso siempre se guarda.

### El diagrama a pantalla completa, y cómo «calibrarlo» bien

Esta es la operación más técnica de la app, así que aquí va el detalle.

Al tocar un diagrama (o el botón «ampliar» de al lado) se abre a
pantalla completa: entonces puedes hacer zoom (pellizcar con dos dedos,
doble toque, o botones +/−) y desplazarte para leer cada punto, con los
mismos botones de seguimiento de fila que en la página.

El problema que resuelve la calibración: el PDF original suele tener
márgenes (texto, espacio en blanco) alrededor de la cuadrícula del
diagrama. Sin un ajuste, la app no sabe dónde empieza y dónde termina la
cuadrícula en la imagen — la banda que te muestra «vas por aquí» podría
caer en el lugar equivocado.

![El modo de calibración de un diagrama](images/es/03c-diagramme-calage.webp)

*El modo de calibración: las dos líneas con flecha que arrastras a los bordes de la cuadrícula, la instrucción, y los tres botones Restablecer / Cancelar / Guardar.*

**Cómo calibrar un diagrama, la primera vez que lo abres:**

1. En pantalla completa, en la barra superior, toca el icono
   **Calibrar** (dos barras horizontales unidas por una flecha
   vertical) — es el primer icono después del título, justo antes de
   los botones de zoom y de cerrar; este botón no lleva texto, solo ese
   pictograma.
2. Aparecen dos líneas con flecha sobre la imagen, cada una con una
   pequeña etiqueta («Parte superior de la cuadrícula» / «Parte
   inferior de la cuadrícula»). Arrastra cada una hasta que quede
   **exactamente sobre el borde de la cuadrícula**: la línea «Parte
   inferior de la cuadrícula» sobre la primerísima **fila** del
   diagrama, la de «Parte superior de la cuadrícula» sobre la última.
   (Ni sobre el texto ni los márgenes de alrededor, ni sobre el borde
   de la propia foto — solo sobre la cuadrícula.)
3. Mientras ajustas, una banda de referencia se queda visible sobre tu
   fila en curso: te sirve para comprobar en directo que encaja bien,
   antes de confirmar.
4. Toca **Guardar** para dejarlo listo. («Cancelar» abandona el ajuste
   en curso; «Restablecer» quita la calibración existente y vuelves a
   empezar desde la imagen completa.)

Una vez calibrado, el seguimiento de fila se mantiene preciso durante el
resto de esa pieza en ese diagrama, dentro de **ese proyecto**. Un
detalle importante: la calibración se guarda junto con el progreso del
proyecto, no con el patrón en sí — así que si empiezas un segundo
proyecto con el mismo patrón, tendrás que repetirla una vez para el
proyecto nuevo (la operación solo lleva unos segundos).

**Seguir tu posición en una fila larga.**

![El mando de progreso sobre la fila en curso](images/es/03d-diagramme-rideau.webp)

*El mando redondo, situado sobre la fila en curso: a su derecha, la parte de la fila ya hecha aparece teñida. Solo existe en esa fila.*

En un diagrama muy ancho, una vez hecho zoom, es fácil perder de vista
en qué punto vas. En pantalla completa aparece un **pequeño mando
redondo** sobre la fila en curso — y solo sobre ella, no sobre todo el
diagrama. Lo arrastras de derecha a izquierda (o al revés) siguiendo tus
puntos: la parte de la fila que deja atrás se tiñe, representando lo
que ya has tejido.

Un botón junto al contador de fila invierte el lado teñido (útil cuando
la siguiente fila se lee en el otro sentido). El mando vuelve solo a su
sitio en cada fila nueva, y su posición se conserva incluso si sales de
la app. La primera vez que abres un diagrama, un pequeño aviso te
señala que está ahí, para que no se te pase.

### En tableta: el diagrama junto al texto

Si tejes con una tableta sujeta en horizontal, el lector cambia solo a
**dos columnas**: tus instrucciones a la izquierda, un diagrama que
queda mostrado de forma permanente a la derecha — ya no tienes que
desplazarte entre los dos. Mantienes el control:

- En cualquier otro diagrama del patrón, el botón **Mostrar a la
  derecha** lo pasa al panel lateral (útil cuando un patrón contiene
  varios).
- El botón **Devolver al texto** cierra el panel y coloca de nuevo el
  diagrama en su sitio dentro del texto, por si prefieres leer todo en
  una sola columna.
- En el punto del texto donde estaba el diagrama, una nota te recuerda
  que **se muestra a la derecha** — nada desaparece sin avisarte.

Este ajuste solo dura mientras consultas el patrón: al volver a
abrirlo, aparece de nuevo el panel con el primer diagrama. En teléfono
(o en una tableta sujeta en vertical), el lector se queda en una sola
columna, como antes. Un patrón sin diagrama no tiene panel en absoluto.

## 4. Tu biblioteca de patrones

![La biblioteca de patrones](images/es/04-bibliotheque.webp)

*La biblioteca, con los tres patrones de muestra incluidos desde el primer inicio.*

![Ficha de un patrón](images/es/04b-fiche-patron.webp)

*La ficha de un patrón, deliberadamente sencilla: crear un proyecto, o previsualizar. (La corrección del import se abre desde la vista previa.)*

- **Importar un PDF**: sueltas el PDF de tu patrón y la app lo lee y
  **reconstruye automáticamente** las tallas, las filas y las
  secciones — gratis, sin conexión a internet y sin enviar nada a
  ningún sitio. Una pantalla de revisión te permite comprobar y
  corregir el resultado antes de guardarlo.
- **Encontrar un patrón**: las etiquetas de categoría en la parte
  superior de la biblioteca te muestran **cuántos patrones** hay en
  cada una, para saber de un vistazo dónde buscar.
- **Corregir un patrón**: un editor a pantalla completa te permite
  retocar un patrón importado (texto, tallas, imágenes) si el import
  automático no lo ha entendido todo bien. Es la otra operación
  técnica de la app — detallada más abajo.
- **Vista de patrón**: lectura sencilla para patrones sin formato
  especial, o patrones que has escrito enteramente a mano.
- **3 patrones de muestra** vienen con la app desde el primer inicio,
  para que descubras todas las funciones sin importar nada.

### El editor de corrección, en detalle

Es la operación más técnica de la app junto con la calibración de
diagramas (arriba): así es como funciona de verdad.

**El principio.** Un patrón está formado por líneas de texto, y **cada
línea lleva una categoría** que le dice a la app para qué sirve: ¿una
casilla que marcar mientras tejes? ¿un título de parte? ¿una simple
información de referencia? El import automático ya asigna una
categoría a cada línea al llegar — el editor te sirve para corregir las
que ha adivinado mal, y para retocar el texto si una frase se ha
cortado mal.

**Las categorías posibles:**

| Categoría | Qué da en tu proyecto |
|---|---|
| **Paso** | Una casilla que marcar al tejer o ganchillar — el corazón del seguimiento paso a paso. |
| **Contador** | Un paso repetido, con su propio contador. Dos variantes: **Repetición** (repetir la línea N veces) y **Cadencia** (repetir la línea cada X filas, N veces). |
| **Nota** | Un texto informativo mostrado en ese punto, sin casilla. |
| **Sección** | Un título de parte (Delantero, Manga, Cuello…), con su icono automático — es lo que divide tu patrón en la pestaña Secciones. |
| **Referencia** | Información de la ficha del patrón (hilo, agujas, tallas…) — **no** forma parte del seguimiento paso a paso. Siete subcategorías: **Hilo** (marca, material, metraje, cantidades), **Agujas** (agujas o ganchillos), **Muestra** (la medida de referencia, ej. «10 × 10 cm = 22 puntos»), **Materiales** (el resto: botones, marcadores…), **Abreviaturas** (una por línea), **Tallas** (la tabla de medidas finales — no las instrucciones por talla, que son Secciones), **Técnicas** (una técnica explicada). Estos bloques son los que rellenan la guía rápida del lector interactivo (sección 3 arriba). |
| **Texto** | Un párrafo simple, sin ningún rol particular. |
| **Imagen** | Una foto o un diagrama. |

**Cómo cambiar la categoría de una línea:**

1. Pones el cursor en la línea (o seleccionas varias líneas a la vez).
   La barra de herramientas justo encima del editor resalta la
   categoría ya aplicada, para que sepas siempre en qué punto estás.
2. Tocas el botón (Paso, Nota, Texto) o eliges en el menú (Contador,
   Sección, Referencia — estas tres tienen subcategorías) según lo que
   deba pasar a ser la línea.
3. El color y el aspecto de la línea cambian al instante para
   confirmarlo.

**Dos formas de ver el texto.** Por defecto, el editor te muestra una
**vista enriquecida**: las imágenes aparecen en miniatura, los
contadores como píldoras, las filas con su casilla — una vista previa
cercana a lo que verás de verdad. El botón **Editar texto** cambia al
texto plano (el marcado se hace visible) y abre el teclado: útil para
corregir una formulación, una errata, o una frase que el import cortó
mal en dos líneas.

**Reordenar sin cortar y pegar.** Dos flechas (subir/bajar) mueven la
línea donde tienes el cursor, práctico si el import colocó un paso o
un título de sección en el sitio equivocado.

**Convertir una foto en diagrama seguible (o al revés).** Un panel
plegable «Diagramas de este patrón», al final del editor, lista cada
sección que contiene una imagen. Para cada una, un botón alterna entre
**Imagen simple** (solo una foto) y **Seguir como diagrama** (la hace
seguible fila a fila en el lector, con la calibración descrita más
arriba) — práctico si el import se ha saltado un diagrama, o al revés,
si quieres que una simple foto siga siendo una simple foto.

**Guardar.** Los botones **Cancelar** / **Guardar** están fijos al pie
de la pantalla. Si intentas salir con cambios sin guardar, la app
detiene la salida y te pide confirmación — tampoco aquí se te pierde
nada por error.

## 5. Tu stock de lana

![El stock de lanas](images/es/05-stock.webp)

*El stock: los totales arriba (ovillos, longitud, peso, valor), y luego una ficha por lana con su estado — libre o reservada por un proyecto.*

- **Añadir un ovillo**: marca, grosor (con una ayuda para entender las
  categorías de grosor), composición (elegida en una lista; si un
  material no aparece, «Otro» te permite escribirlo, y a partir de ahí
  se te ofrece como los demás), color (elegido en una paleta, con un
  selector de tono personalizado si hace falta), cantidad, precio,
  longitud y peso por ovillo, más la fecha de compra y el número de
  baño de tinte.
  **En cuanto guardas, la app registra al instante la compra
  correspondiente**, y tu presupuesto gastado (punto 1) sube por el
  importe indicado. La fecha que te propone es la de hoy: si compraste
  esa lana hace más tiempo, puedes corregirla directamente en el
  formulario. (Estos dos campos solo aparecen al crear la ficha. En una
  ficha ya guardada, es el bloque **Compras y regalos** el que se
  encarga, con una línea por adquisición.)
- **Las lanas que no son de un solo color**: un campo **Tipo de color**
  (liso, degradado, autorrayado, jaspeado, teñido a mano) y un campo
  **Descripción del color** («azul, verde, amarillo jaspeado de negro»)
  completan la pastilla de color — porque un solo tono no basta para
  describir una lana multicolor. El tipo de color aparece también en
  la búsqueda y en la exportación a hoja de cálculo.
- **El resumen** en la parte superior de la pantalla: número de
  ovillos, longitud y peso acumulados (que cambian solos a km y kg
  cuando los totales crecen), y el valor total de tu stock.
- **Buscar y ordenar** tu lana por marca o por grosor, en lista o en
  cuadrícula visual.
- **Editar, duplicar o eliminar** una ficha desde el menú **Acciones**
  (icono vertical de tres puntos) de su tarjeta. «Duplicar» te resulta
  útil para la misma lana en otro color: se copia todo, solo te queda
  cambiar el color.
- **El fondo común de ovillos**: ves de un vistazo, para cada lana,
  cuántos ovillos tienes **reservados** para un proyecto y cuántos
  **libres**. No puedes bajar la cantidad por debajo de lo ya
  reservado (la app te indica cuántos ovillos quedan retenidos); y te
  avisa si restaurar un proyecto desde la papelera pone en duda tus
  reservas de lana — el proyecto vuelve igualmente, pero con una
  reserva reducida y un mensaje que te lo explica.
- **Ficha de detalle** de una lana: un resumen completo (ovillos,
  metros, proyectos que la usan), y un bloque **Compras y regalos** que
  guarda para ti el registro de cada adquisición de esa lana:
  - Cada línea lleva una cantidad, un precio, una fecha y un baño de
    tinte, e indica si fue una **compra** o un **regalo** (un regalo
    nunca cuenta en tu presupuesto gastado). Las tres líneas más
    recientes las ves de inmediato, el resto se despliega con un
    gesto.
  - Una línea la puedes **añadir, editar o eliminar** en cualquier
    momento.
  - **Si aumentas la cantidad** de una lana desde su ficha, la app te
    propone registrar la compra correspondiente, fechada hoy: puedes
    aceptarla, marcarla como regalo, o descartarla si no quieres
    conservarla. **Disminuir una cantidad, en cambio, nunca toca tu
    presupuesto gastado** — solo un aumento puede crear una compra.
  - Si el número de ovillos de la ficha no coincide con lo que
    registra el historial (por ejemplo tras una corrección manual del
    stock), un aviso te lo señala y un botón **Corregir** te ofrece
    dos soluciones: añadir la compra que falta, o ajustar la cantidad
    mostrada.
  - Una compra conserva su etiqueta aunque elimines definitivamente la
    ficha de la lana: nada de lo que has gastado desaparece, sigue
    visible en la pantalla **Gastos**.

### La pantalla Gastos

Accesible tocando el presupuesto gastado en el inicio (punto 1), esta
pantalla te resume todo lo que has pagado por lana:
- El **total gastado**, por moneda si has usado más de una.
- Un **filtro por año**: un menú **Año** en la parte superior de la
  pantalla te muestra solo el año elegido (o «Todos los años»), y los
  totales se recalculan en consecuencia. Las compras cuya fecha no
  hayas registrado acaban bajo «Fecha desconocida», que se añade al
  menú cuando las hay.
- Un **desglose por año y luego por mes**, para que veas a dónde va tu
  presupuesto con el tiempo.
- La **lista completa** de todas tus compras y regalos, incluidos
  aquellos cuya ficha de lana hayas eliminado después (marcados como
  «Lana eliminada»).
- La posibilidad de **eliminar** una línea directamente desde esta
  pantalla, con opción de **deshacerlo** justo después si fue un
  error.

## 6. Herramientas independientes

![El contador libre](images/es/06a-compteurs.webp)

*El contador libre, utilizable sin proyecto: le das un nombre y eliges si sigue aumentos/disminuciones o repeticiones.*

![La calculadora](images/es/06b-calculateur.webp)

*La calculadora de puntos: repartir aumentos o disminuciones entre un número de filas, o averiguar cuántas filas necesitas a un ritmo dado — en plano o en redondo.*

Estas herramientas funcionan sin estar ligadas a un proyecto concreto,
accesibles desde el inicio:
- **Calculadora de puntos**: responde en los dos sentidos. O le das un número
  de filas y te dice cómo repartir en ellas tus aumentos o disminuciones; o le
  das tu ritmo («cada 4 filas») y te dice cuántas filas necesitas para llegar a
  tu número de puntos objetivo, y en qué fila cae el último cambio. Un campo
  indica cuántos puntos añades o quitas cada vez: normalmente 1, o 2 en una
  manga donde aumentas un punto a cada lado. Cuando tu objetivo no se alcanza
  exacto, te propone las dos posibilidades que lo rodean en vez de redondear
  sin decirlo. En plano habla de filas; en redondo, de vueltas.
- **Contador libre**: uno o varios contadores independientes (+/−, un
  objetivo por alcanzar, reinicio), para todo lo que no pertenezca a
  un proyecto guardado.
- **Encontrar tu talla de agujas (o de ganchillo)**: introduces lo que
  viene escrito en la etiqueta del ovillo (talla de aguja recomendada
  y número de puntos por 10 × 10 cm, o 4 × 4 pulgadas) y luego la
  muestra que pide tu patrón, y la app te dice por qué talla empezar
  — una por encima, una por debajo, o la misma. También te avisa
  cuando la diferencia es demasiado grande para compensarla (esa lana
  no combina con ese patrón), y te recuerda siempre que te queda por
  tejer una muestra para comprobarlo: es un punto de partida, no una
  garantía. El campo de las filas es opcional.

## 7. Estadísticas

![La pantalla de estadísticas](images/es/07-statistiques.webp)

*El tiempo dedicado, por semana, mes o año. El total en curso vuelve a cero cada lunes; el historial, en cambio, acumula.*

El tiempo que has dedicado a tejer o ganchillar, por semana y por mes,
en todos tus proyectos — para que te des cuenta de tu propia
constancia (o disfrutes viendo el camino recorrido).

## 8. Ajustes

![Los ajustes](images/es/08-reglages.webp)

*La parte superior de ajustes: nombre, técnica por defecto, tema, idioma, unidades y moneda. Más abajo están la carpeta de copia de seguridad y la papelera.*

- **Perfil**: tu nombre (usado para el saludo en el inicio) y tu
  técnica por defecto (punto o ganchillo).
- **Apariencia**: tema claro, oscuro, o según el de tu teléfono.
- **Idioma**: francés, inglés, alemán o español. Cada idioma aparece
  escrito en su propio idioma en la lista («Deutsch», «Español»), para
  que encuentres el tuyo con facilidad.
- **Unidades y moneda**:
  - **Métrico** (metros, gramos) o **imperial** (yardas, onzas,
    libras) — todo sigue: la entrada de tus ovillos, los totales del
    stock, la muestra (10 × 10 cm o 4 × 4 pulgadas). Cambiar de
    sistema no modifica ninguna de tus cifras guardadas, solo te las
    muestra de nuevo en la otra unidad.
  - **Moneda** entre cinco (€, $, £, CHF, CA$). Ojo, es solo una
    etiqueta: los precios que ya has introducido **no se convierten**,
    se muestran con el otro símbolo — la app te lo recuerda antes de
    confirmar.
  - Estos dos ajustes se te proponen ya **desde la primera pantalla**
    al abrir la app, rellenados de antemano según el idioma de tu
    teléfono; puedes cambiarlos aquí en cualquier momento.
- **Datos**:
  - Exportación de tu stock, tus proyectos o tus patrones a hoja de
    cálculo (CSV), para consultarlos o guardarlos en otro sitio. Las
    columnas siguen tus ajustes actuales: longitudes y pesos en el
    sistema de unidades elegido, precios con el símbolo de la moneda
    elegida.
  - Una **papelera** universal: todo proyecto, lana o patrón eliminado
    acaba ahí y puedes restaurarlo en cualquier momento (hasta que la
    vacíes a propósito).
- **Carpeta de {app}**: eliges una carpeta en tu teléfono (o una
  carpeta sincronizada) en la que la app **guarda de forma continua**
  todo lo que haces, como archivos legibles — sin necesidad de tocar
  «Guardar». Si reinstalas la app y vuelves a elegir la misma carpeta,
  todo vuelve tal como estaba.
- **Contribuir**: enlace al código fuente (la app es de código
  abierto) y a las formas de apoyarla.

## 9. Bajo el capó — lo que {app} te garantiza

- **Sin conexión por defecto**: ningún dato tuyo sale nunca del
  teléfono, salvo la carpeta de copia de seguridad que **tú eliges**.
- **Sin cuenta, sin muro de pago**: todas las funciones anteriores son
  gratuitas, sin ninguna función esencial bloqueada.
- **Nada se pierde por error**: cada eliminación la puedes deshacer al
  instante, y de todos modos acaba en la papelera.
- **Pensada para que todo el mundo pueda leerla**: contrastes
  suficientes, botones lo bastante grandes para tocarlos con
  facilidad, compatible con lectores de pantalla.
- **Cómoda en cualquier pantalla**: en un teléfono pequeño nada se sale
  ni se corta; en una tableta, la app aprovecha el espacio — tus
  listas de proyectos y patrones se reparten en varias columnas en
  lugar de una sola pila larga, y el lector puede mantener el diagrama
  junto al texto. La app tiene en cuenta las zonas reservadas de la
  pantalla (barra de estado, muesca, barra de navegación): el
  contenido ya no se desliza debajo de ellas.
- **En cuatro idiomas**: francés, inglés, alemán y español.
