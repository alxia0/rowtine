# {app}-Leitfaden

## Was {app} ausmacht

![Ersteinrichtung von {app}](images/de/00-bienvenue.webp)

*Der allererste Start: Vorname, Technik, Sprache und Erscheinungsbild.*

{app} hilft dir dabei, alle deine Strick- und Häkelprojekte an einem Ort zu
sammeln: dein Garn, deine an deine Größe angepassten Anleitungen und
deinen Fortschritt. Die App ist **kostenlos und quelloffen, und sie funktioniert
offline** — deine Daten bleiben auf deinem Smartphone, nicht auf einem
Server. Nichts geht aus Versehen verloren: Alles, was du löschst, landet
im Papierkorb.

## 1. Start — deine Übersicht

![Der Startbildschirm von {app}](images/de/01-accueil.webp)

*Start: Die Kachel „Fortsetzen“ bringt dich zurück zu dem Projekt, an dem du zuletzt gestrickt oder gehäkelt hast, die beiden Zähler fassen das Wichtigste zusammen, und die drei Werkzeuge sind in Griffweite.*

Beim Öffnen der App findest du:
- **Dein letztes Projekt**, mit einer Schaltfläche **Fortsetzen**, um
  genau dort weiterzumachen, wo du aufgehört hast. Es handelt sich
  wirklich um das Projekt, an dem du **zuletzt tatsächlich gestrickt oder
  gehäkelt** hast (deine letzte Sitzung), nicht einfach um das zuletzt
  bearbeitete — und es zeigt dir die aktuelle Reihe an.
- Eine **Zusammenfassung**: wie viele Projekte gerade in Arbeit sind, die
  Zeit, die du diese Woche mit Stricken oder Häkeln verbracht hast (mit
  Details unter **Statistik**), und dein **ausgegebenes Budget** — die
  Summe von allem, was du für Garn bezahlt hast, seit du die App nutzt, in
  der von dir gewählten Währung. Diese Zahl sinkt nie von selbst: Ein
  Wenn du ein Knäuel verbrauchst oder ein Projekt abschließt, sinkt sie nicht
  (nur ein neuer Kauf lässt sie steigen); sie kann nur sinken, wenn du
  selbst eine Kaufzeile im Block „Käufe und Geschenke“ einer Garnkarte
  löschst oder korrigierst (Punkt 5). (Hast du mehrere Währungen
  verwendet, hat jede ihre eigene Summe: Die App vermischt sie nie, da
  sie keinen Wechselkurs kennt.) Tippst du auf diese Zahl, öffnest du den
  Bildschirm **Ausgaben**, beschrieben in Punkt 5. Diese Kachel erscheint
  nicht, solange du noch keinen Kauf erfasst hast (zum Beispiel bei
  einer brandneuen Installation).
- Diese Zahl unterscheidet sich von deinem **Vorratswert**, angezeigt im
  Bildschirm **Garnvorrat** (Punkt 5): Der zeigt, was aktuell in
  deinem Schrank liegt, und sinkt, wenn du ein Knäuel verbrauchst. Beide
  Zahlen gibt es bewusst nebeneinander: Die eine zeigt, was du
  ausgegeben hast, die andere, was dir noch übrig bleibt.
- Alle deine Projekte, **nach Status gruppiert** (in Arbeit, geplant,
  pausiert, fertig, aufgegeben), mit einer Schaltfläche, um alle
  anzuzeigen oder die Liste einzuklappen.
- Schneller Zugriff auf die **Werkzeuge** (Maschenrechner, freier Zähler,
  Nadel-/Häkelnadelhilfe) und die Schaltfläche **+ Projekt erstellen**.

## 2. Deine Projekte — das Herzstück der App

![Eine Projektkarte, Reiter Abschnitte](images/de/02-fiche-projet.webp)

*Eine Projektkarte: der Gesamtfortschritt, die Schaltfläche „Anleitung folgen“, dann eine Kachel pro Abschnitt mit eigenem Fortschritt und eigenem „Fertig“-Kästchen.*

### Erstellen, bearbeiten, löschen

Ein Projekt entsteht in wenigen Sekunden: Name, Technik (Stricken oder
Häkeln), verknüpfte Anleitung (oder „Freie Anleitung“, falls du keine
verwendest). Wählst du eine vorhandene Anleitung, **füllt die App
Größen, Stricknadeln oder Häkelnadel, Maschenprobe und Projekttyp
automatisch voraus** — du musst nur noch anpassen. Ein gelöschtes Projekt geht **nicht sofort
verloren**: Du kannst das Löschen direkt danach rückgängig machen oder
das Projekt später aus dem Papierkorb (Einstellungen) wiederherstellen.

### Die Projektkarte, mit Reitern

- **Abschnitte**: die Etappen deiner Arbeit (Vorderteil, Rückenteil,
  Ärmel…), jeweils mit einem Status-Abzeichen (geplant / begonnen / in
  Arbeit / fertig) und, sofern die Anleitung ein Diagramm enthält, einer
  Vorschau des zugehörigen Diagramms.
- **Details**: alle Projektinformationen — Technik, Größen, Nadeln oder
  Häkelnadel, Maschenprobe, Start-/Enddatum, deine Bewertung in Sternen
  und eine persönliche Notiz.
- **Fotos**: deine eigenen Projektfotos und dazu die Originalfotos der
  Anleitung. Du legst fest, welches als **Cover** dient (Standard: das
  erste Foto der Anleitung).
- **Sitzungen**: der Verlauf deiner Strick-/Häkelsitzungen, mit der Dauer
  jeder einzelnen und der Möglichkeit, eine Sitzung
  manuell hinzuzufügen (falls du ohne geöffnete App gestrickt hast).

### Live arbeiten — die Sitzung

Öffnest du einen Abschnitt zum Stricken oder Häkeln, erwartet dich:
- Ein **Timer** unten am Bildschirmrand. Er **startet nicht von selbst**:
  Du tippst ihn an, um ihn zu starten, und tippst erneut, um ihn bei
  einer Unterbrechung zu pausieren (die Schaltfläche zeigt dann
  **Fortsetzen** mit der bereits gezählten Zeit). Einmal gestartet, läuft
  er weiter, selbst wenn du den Bildschirm ausschaltest, eine andere App
  öffnest oder dein Smartphone neu startet — du findest den Faden immer
  wieder.
- Du **hakst Reihen ab**, Schritt für Schritt, mit den angezeigten
  Anleitungszeilen (bis zu 8 sichtbare Zeilen; die App bringt dich
  automatisch genau dorthin zurück, wo du aufgehört hast).
- Du verwaltest mehrere **Zähler** pro Projekt (Maschen, Reihen,
  Wiederholungen…), jeweils mit einer +/−-Schaltfläche und einer
  Korrekturmöglichkeit, falls du dich verzählst.
- Eine Schaltfläche **Schließen und speichern** archiviert die Sitzung
  sauber im Reiter Sitzungen.

## 3. Die Anleitung, die sich dir anpasst — der interaktive Lesemodus

![Der Lesemodus: Größenwahl und Merkblatt](images/de/03a-lecteur-haut.webp)

*Oben im Lesemodus: Du wählst deine Größe einmal, und das Merkblatt (Material, Größentabelle, Techniken, Abkürzungen) bleibt in Griffweite.*

![Der Lesemodus: Diagramm reihenweise verfolgt](images/de/03b-lecteur-diagramme.webp)

*Weiter unten: Du folgst dem Diagramm Reihe für Reihe, mit eigenem Zähler „Diagrammreihe“, Leserichtung und dem Timer am Bildschirmrand.*

Das ist die Kernfunktion von {app}. Sobald eine Anleitung in das Format
„geführtes Lesen“ gebracht wurde (die 3 Beispielanleitungen liegen bereits so
vor, ebenso jede importierte und geprüfte Anleitung), bekommst du:

- **Die Größenwahl**: Du wählst deine Größe einmal, und **alle Zahlen der
  Anleitung passen sich automatisch deiner Größe an** (Maschen,
  Reihen, Längen). Schluss mit dem Entziffern von Notationen wie
  „104 (108) 112…“ bei jeder Zeile.
- **Die Schritt-für-Schritt-Begleitung**: Jeden Schritt kannst du
  abhaken, mit einem Fortschrittsbalken fürs Ganze und einem
  je Abschnitt sowie eingebauten Wiederholungszählern
  („− 3/12 +“), die von selbst verschwinden, falls sie nicht zu deiner
  gewählten Größe gehören.
- **Das interaktive Diagramm**: das Diagramm der Anleitung (unverändert aus
  dem Original-PDF übernommen) mit einer **Markierung, die deiner aktuellen
  Reihe folgt**, bereits abgearbeiteten, ausgegrauten Reihen und einem
  Zähler „Reihe X von 52“. Direkt auf der Seite oder über eine
  schwebende Schaltfläche erreichbar, mit einem Zustand, der zwischen
  allen Abschnitten geteilt wird, die dasselbe Diagramm verwenden.
- **Das Merkblatt**: Die Abkürzungen der Anleitung erscheinen als
  Sprechblase, sobald du sie antippst, ohne dass du deine aktuelle Reihe
  verlässt; ein vollständiges Panel bündelt außerdem die Techniken (mit
  Video-Anleitungen), Material und Maschenprobe, die Größentabelle, die
  Liste der Abkürzungen sowie die von der Anleitung gegebenen **Tipps und
  Tricks**.
- Eine Anleitung kannst du lesend ansehen (Vorschau aus der Bibliothek)
  **oder** deinen tatsächlichen Fortschritt von einem Projekt aus
  verfolgen — beide Zugänge bestehen nebeneinander, und dein Fortschritt
  wird immer gespeichert.

### Das Diagramm im Vollbild, und wie du es richtig „ausrichtest“

Das ist der technischste Vorgang der App, daher hier alle Einzelheiten.

Tippst du auf ein Diagramm (oder auf die Schaltfläche „Vergrößern“
daneben), öffnest du es im Vollbild: Du kannst dann zoomen
(Zwei-Finger-Zoom, Doppeltipp oder +/−-Schaltflächen) und dich
verschieben, um jede Masche zu lesen, mit denselben
Reihenverfolgungs-Schaltflächen wie auf der Seite.

Das Problem, das die Ausrichtung löst: Das Original-PDF hat um das
Raster des Diagramms herum oft Ränder (Text, Leerraum). Ohne Einstellung
weiß die App nicht, wo das Raster auf dem Bild beginnt und endet — das
Band, das dir „hier bist du gerade“ zeigt, könnte an der falschen Stelle
landen.

![Der Ausrichtungsmodus eines Diagramms](images/de/03c-diagramme-calage.webp)

*Der Ausrichtungsmodus: die beiden Pfeillinien, die du auf die Ränder des Rasters ziehst, die Anweisung, und die drei Schaltflächen Zurücksetzen / Abbrechen / Speichern.*

**So richtest du ein Diagramm aus, beim ersten Öffnen:**

1. Tippe im Vollbild, in der oberen Leiste, auf das Symbol **Ausrichten**
   (zwei horizontale Balken, verbunden durch einen senkrechten Pfeil) —
   das erste Symbol nach dem Titel, direkt vor den Zoom- und
   Schließen-Schaltflächen; diese Schaltfläche trägt keinen Text, nur
   dieses Piktogramm.
2. Zwei Pfeillinien erscheinen auf dem Bild, jede mit einer kleinen
   Beschriftung („Oberkante des Rasters“ / „Unterkante des Rasters“).
   Ziehe jede **genau auf den Rand des Rasters**: die Linie „Unterkante
   des Rasters“ auf die allererste **Reihe** des Diagramms, „Oberkante
   des Rasters“ auf die allerletzte. (Nicht auf den Text oder die Ränder
   darum, auch nicht auf den Rand des Fotos selbst — nur auf das
   Raster.)
3. Während du anpasst, bleibt ein Orientierungsband auf deiner aktuellen
   Reihe sichtbar: Nutze es, um live zu prüfen, ob alles passt, bevor du
   bestätigst.
4. Tippe auf **Speichern**, um abzuschließen. („Abbrechen“ verwirft die
   laufende Einstellung; „Zurücksetzen“ entfernt eine vorhandene
   Ausrichtung und du beginnst wieder beim vollständigen Bild.)

Nach der Ausrichtung bleibt die Reihenverfolgung für den Rest deines
Stücks auf diesem Diagramm präzise, innerhalb **dieses Projekts**. Zu
beachten: Die Ausrichtung wird zusammen mit deinem Projektfortschritt
gespeichert, nicht mit der Anleitung selbst — beginnst du also ein
zweites Projekt aus derselben Anleitung, musst du sie einmal für das
neue Projekt wiederholen (der Vorgang dauert nur wenige Sekunden).

**Deine Position in einer langen Reihe verfolgen.**

![Der Fortschrittsgriff auf der aktuellen Reihe](images/de/03d-diagramme-rideau.webp)

*Der runde Griff, auf der aktuellen Reihe: Rechts davon ist der bereits gearbeitete Teil der Reihe eingefärbt. Er existiert nur auf genau dieser Reihe.*

Bei einem sehr breiten Diagramm ist es nach dem Zoomen leicht, den Faden
zur aktuellen Masche zu verlieren. Im Vollbild erscheint ein **kleiner
runder Griff** auf der aktuellen Reihe — und nur auf ihr, nicht auf dem
ganzen Diagramm. Ziehst du ihn von rechts nach links (oder umgekehrt) im
Takt deiner Maschen, färbt sich der dahinter liegende Teil der Reihe
ein, als Darstellung dessen, was du bereits gestrickt hast.

Eine Schaltfläche neben dem Reihenzähler kehrt die eingefärbte Seite um
(nützlich, wenn sich die nächste Reihe in die andere Richtung liest).
Der Griff kehrt bei jeder neuen Reihe von selbst an seinen Platz zurück,
und deine Position bleibt auch erhalten, wenn du die App verlässt. Beim
ersten Öffnen eines Diagramms weist dich eine kleine Meldung darauf hin,
damit er dir nicht entgeht.

### Auf dem Tablet: das Diagramm neben dem Text

Strickst du auf einem quer gehaltenen Tablet, stellt sich der Reader von
selbst auf **zwei Spalten** um: deine Anleitung links, ein dauerhaft
angezeigtes Diagramm rechts — du musst nicht mehr zwischen beiden hin-
und herscrollen. Du behältst die Kontrolle:

- Bei jedem anderen Diagramm der Anleitung bringt dir die Schaltfläche
  **Rechts anzeigen** es in das Seitenfeld (praktisch, wenn eine
  Anleitung mehrere enthält).
- Die Schaltfläche **Zurück in den Text** schließt das Feld wieder und
  setzt das Diagramm zurück an seinen Platz im Textfluss, falls du
  lieber alles in einer einzigen Spalte liest.
- An der Stelle im Text, an der das Diagramm stand, erinnert dich ein
  Verweis daran, dass es **rechts angezeigt wird** — nichts verschwindet,
  ohne es dir zu sagen.

Diese Einstellung gilt nur für deine aktuelle Sitzung: Öffnest du die
Anleitung erneut, erscheint das Feld wieder mit dem ersten Diagramm. Auf
dem Smartphone (oder einem hochkant gehaltenen Tablet) bleibt der Reader
einspaltig, wie zuvor. Eine Anleitung ohne Diagramm hat gar kein
Seitenfeld.

## 4. Deine Anleitungsbibliothek

![Die Anleitungsbibliothek](images/de/04-bibliotheque.webp)

*Die Bibliothek, mit den drei beim ersten Start mitgelieferten Beispielanleitungen.*

![Eine Anleitungskarte](images/de/04b-fiche-patron.webp)

*Eine Anleitungskarte, bewusst schlicht gehalten: ein Projekt erstellen oder eine Vorschau ansehen. (Die Korrektur des Imports erreichst du über die Vorschau.)*

- **Ein PDF importieren**: Du legst das PDF deiner Anleitung ab, die App
  liest es und **rekonstruiert automatisch** Größen, Reihen und
  Abschnitte — kostenlos, ohne Internetverbindung und ohne dass irgendwo
  etwas gesendet wird. Ein Prüfbildschirm lässt dich das Ergebnis vor
  dem Speichern kontrollieren und korrigieren.
- **Eine Anleitung wiederfinden**: Die Kategorie-Chips oben in der
  Bibliothek zeigen dir **die Anzahl der Anleitungen** je Kategorie, um
  auf einen Blick zu wissen, wo du suchen musst.
- **Eine Anleitung korrigieren**: Ein Vollbild-Editor lässt dich eine
  importierte Anleitung nachbessern (Text, Größen, Bilder), falls der
  automatische Import nicht alles richtig erfasst hat. Das ist der
  andere technische Vorgang der App — Details weiter unten.
- **Anleitungsansicht**: einfache Leseansicht für Anleitungen ohne
  besondere Formatierung oder Anleitungen, die du vollständig von Hand
  eingegeben hast.
- **3 Beispielanleitungen** bekommst du schon beim ersten Start mit der
  App mitgeliefert, um alle Funktionen zu entdecken, ohne etwas zu
  importieren.

### Der Korrektur-Editor im Detail

Das ist der technischste Vorgang der App neben der Diagrammausrichtung
(siehe oben): So funktioniert er wirklich.

**Das Prinzip.** Eine Anleitung besteht aus Textzeilen, und **jede Zeile
trägt eine Kategorie**, die der App sagt, wofür sie dient: ein Kästchen
zum Abhaken beim Stricken? ein Abschnittstitel? eine reine
Referenzinformation? Der automatische Import weist beim Eintreffen
bereits jeder Zeile eine Kategorie zu — der Editor dient dir dazu, falsch
erratene Zuweisungen zu korrigieren und den Text nachzubessern, falls
ein Satz schlecht getrennt wurde.

**Die möglichen Kategorien:**

| Kategorie | Was daraus in deinem Projekt wird |
|---|---|
| **Schritt** | Ein Kästchen zum Abhaken beim Stricken oder Häkeln — das Herzstück der Schritt-für-Schritt-Verfolgung. |
| **Zähler** | Ein wiederholter Schritt, mit eigenem Zähler. Zwei Varianten: **Wiederholung** (die Zeile N-mal wiederholen) und **Kadenz** (die Zeile alle X Reihen wiederholen, N-mal). |
| **Notiz** | Ein informativer Text an dieser Stelle, ohne Kästchen. |
| **Abschnitt** | Ein Abschnittstitel (Vorderteil, Ärmel, Kragen…), mit automatischem Symbol — er unterteilt deine Anleitung im Reiter Abschnitte. |
| **Referenz** | Eine Information von der Anleitungskarte (Garn, Nadeln, Größen…) — **kein** Bestandteil der Schritt-für-Schritt-Verfolgung. Sieben Unterkategorien: **Garn** (Marke, Material, Lauflänge, Mengen), **Nadeln** (Nadeln oder Häkelnadeln), **Maschenprobe** (das Referenzmaß, z. B. „10 × 10 cm = 22 Maschen“), **Material** (der Rest: Knöpfe, Markierer…), **Abkürzungen** (eine pro Zeile), **Größen** (die Tabelle der fertigen Maße — nicht die Anleitungen je Größe, das sind Abschnitte), **Techniken** (eine erklärte Technik). Diese Blöcke füllen das Merkblatt des interaktiven Readers (Abschnitt 3 oben). |
| **Text** | Ein einfacher Absatz, ohne besondere Rolle. |
| **Bild** | Ein Foto oder ein Diagramm. |

**Wie du die Kategorie einer Zeile änderst:**

1. Setze deinen Cursor auf die Zeile (oder wähle mehrere Zeilen
   gleichzeitig aus). Die Werkzeugleiste direkt über dem Editor zeigt
   dir die bereits zugewiesene Kategorie hervorgehoben an, sodass du
   immer weißt, wo du stehst.
2. Tippe auf die Schaltfläche (Schritt, Notiz, Text) oder wähle im Menü
   (Zähler, Abschnitt, Referenz — diese drei mit Unterkategorien), was
   die Zeile werden soll.
3. Farbe und Darstellung der Zeile ändern sich sofort zur Bestätigung.

**Zwei Textansichten.** Standardmäßig zeigt dir der Editor eine
**erweiterte Ansicht**: Bilder erscheinen als Miniaturen, Zähler als
Pillen, Reihen mit ihrem Kästchen — eine Vorschau, die dem echten
Ergebnis nahekommt. Die Schaltfläche **Text bearbeiten** wechselt zum
reinen Text (die Auszeichnung wird sichtbar) und öffnet die Tastatur:
nützlich, um eine Formulierung, einen Tippfehler oder einen vom Import
schlecht in zwei Zeilen getrennten Satz zu korrigieren.

**Umsortieren ohne Ausschneiden und Einfügen.** Zwei Pfeile (nach
oben/unten) verschieben die Zeile, in der dein Cursor steht, praktisch,
falls der Import einen Schritt oder einen Abschnittstitel an die
falsche Stelle gesetzt hat.

**Ein Foto in ein verfolgbares Diagramm verwandeln (oder umgekehrt).**
Ein einklappbares Banner „Diagramme dieser Anleitung“ unten im Editor
listet jeden Abschnitt mit einem Bild auf. Für jeden davon wechselt eine
Schaltfläche zwischen **Einfaches Bild** (nur ein Foto) und **Als
Diagramm verfolgen** (macht es dir Reihe für Reihe im Reader verfolgbar,
mit der oben beschriebenen Ausrichtung) — praktisch, falls der Import
ein Diagramm übersehen hat, oder umgekehrt, falls ein einfaches Foto ein
einfaches Foto bleiben soll.

**Speichern.** Die Schaltflächen **Abbrechen** / **Speichern** sind
unten am Bildschirm fixiert. Versuchst du, mit ungespeicherten
Änderungen zu verlassen, stoppt dich die App und bittet um eine
Bestätigung — auch hier geht dir nichts aus Versehen verloren.

## 5. Dein Garnvorrat

![Der Garnvorrat](images/de/05-stock.webp)

*Der Vorrat: die Summen oben (Knäuel, Länge, Gewicht, Wert), dann eine Karte pro Garn mit ihrem Status — frei oder für ein Projekt reserviert.*

- **Ein Knäuel hinzufügen**: Marke, Stärke (mit einer Hilfe zum
  Verständnis der Stärkekategorien), Material (aus einer Liste gewählt;
  fehlt dir ein Material, lässt dich „Andere“ es selbst eingeben, und es
  wird danach wie die übrigen angeboten), Farbe (aus einer Palette
  gewählt, mit eigenem Farbwähler bei Bedarf), Menge, Preis, Länge und
  Gewicht je Knäuel, sowie Kaufdatum und Färbebadnummer.
  **Sobald du speicherst, erfasst die App sofort den entsprechenden
  Kauf**, und dein ausgegebenes Budget (Punkt 1) steigt um den
  angegebenen Betrag. Als Datum wird dir der heutige Tag vorgeschlagen:
  Hast du dieses Garn schon früher gekauft, kannst du das direkt im
  Formular korrigieren. (Diese beiden Felder erscheinen nur bei der
  Erstellung. Bei einer bereits gespeicherten Karte übernimmt der Block
  **Käufe und Geschenke**, mit einer Zeile pro Erwerb.)
- **Garn, das nicht einfarbig ist**: Ein Feld **Farbtyp** (uni,
  Farbverlauf, selbststreifend, gesprenkelt, handgefärbt) und ein Feld
  **Beschreibung der Farbstellung** („blau, grün, gelb gesprenkelt mit
  Schwarz“) ergänzen die Farbmarkierung — weil ein einziger Farbton nicht
  ausreicht, um ein mehrfarbiges Garn zu beschreiben. Der Farbtyp taucht
  auch in der Suche und im Tabellenexport auf.
- **Die Zusammenfassung** oben im Bildschirm: Anzahl der Knäuel,
  Gesamtlänge und -gewicht (die sich von selbst in km und kg umschalten,
  sobald die Summen groß werden), sowie der Gesamtwert deines Vorrats.
- **Suchen und sortieren** nach Marke oder Stärke, als Liste oder als
  visuelles Raster.
- **Bearbeiten, duplizieren oder löschen** einer Karte über das Menü
  **Aktionen** (senkrechtes Dreipunkt-Symbol) auf ihrer Karte.
  „Duplizieren“ ist praktisch für dasselbe Garn in einer anderen
  Farbstellung: alles wird übernommen, du musst nur noch die Farbe
  ändern.
- **Der Knäuelpool**: Für jedes Garn siehst du auf einen Blick, wie
  viele Knäuel für ein Projekt **reserviert** und wie viele **frei**
  sind. Du kannst die Menge nicht unter das bereits Reservierte senken
  (die App zeigt dir an, wie viele Knäuel zurückgehalten werden); und
  sie warnt dich, falls das Wiederherstellen eines Projekts aus dem
  Papierkorb deine Garnreservierungen infrage stellt — das Projekt kommt
  trotzdem zurück, aber mit einer verringerten Reservierung und einer
  Meldung, die es dir erklärt.
- **Detailkarte eines Garns**: eine vollständige Übersicht (Knäuel,
  Meter, Projekte, die es verwenden), und ein Block **Käufe und
  Geschenke**, der jeden Erwerb dieses Garns für dich nachhält:
  - Jede Zeile trägt eine Menge, einen Preis, ein Datum und ein
    Färbebad und gibt an, ob es sich um einen **Kauf** oder ein
    **Geschenk** handelte (ein Geschenk zählt nie zu deinem
    ausgegebenen Budget). Die drei jüngsten Zeilen siehst du sofort,
    den Rest klappst du mit einer Geste auf.
  - Eine Zeile kannst du jederzeit **hinzufügen, bearbeiten oder
    löschen**.
  - **Erhöhst du die Menge** über die Garnkarte, bietet dir die App an,
    den entsprechenden Kauf zu erfassen, datiert auf heute: Du kannst
    ihn übernehmen, als Geschenk kennzeichnen oder verwerfen, falls du
    ihn nicht behalten willst. **Eine Menge zu verringern rührt dagegen
    nie an dein ausgegebenes Budget** — nur eine Erhöhung kann einen
    Kauf anlegen.
  - Stimmt die Knäuelanzahl der Karte nicht mit dem im Verlauf
    Erfassten überein (etwa nach einer manuellen Vorratskorrektur),
    weist dich ein Hinweis darauf hin, und eine Schaltfläche
    **Korrigieren** bietet dir zwei Lösungen an: den fehlenden Kauf
    hinzufügen oder die angezeigte Menge anpassen.
  - Ein Kauf behält seine Bezeichnung, selbst wenn du die Garnkarte
    endgültig löschst: Nichts von dem, was du ausgegeben hast,
    verschwindet, es bleibt im Bildschirm **Ausgaben** sichtbar.

### Der Ausgaben-Bildschirm

Erreichbar, indem du das ausgegebene Budget auf dem Startbildschirm
antippst (Punkt 1), fasst dir dieser Bildschirm alles zusammen, was du
für Garn bezahlt hast:
- Die **Gesamtausgabe**, nach Währung, falls du mehrere verwendet hast.
- Eine **Filterung nach Jahr**: Ein Menü **Jahr** oben im Bildschirm
  zeigt dir nur das gewählte Jahr an (oder „Alle Jahre“), und die
  Summen werden entsprechend neu berechnet. Käufe, deren Datum du nicht
  erfasst hast, landen unter „Unbekanntes Datum“, das dem Menü
  hinzugefügt wird, sobald es welche gibt.
- Eine **Aufschlüsselung nach Jahr, dann nach Monat**, damit du siehst,
  wohin dein Budget im Laufe der Zeit fließt.
- Die **vollständige Liste** all deiner Käufe und Geschenke,
  einschließlich jener, deren Garnkarte du inzwischen gelöscht hast
  (gekennzeichnet mit „Garn gelöscht“).
- Die Möglichkeit, eine Zeile direkt von diesem Bildschirm aus zu
  **löschen**, mit der Möglichkeit, es bei einem Versehen gleich danach
  **rückgängig** zu machen.

## 6. Eigenständige Werkzeuge

![Der freie Zähler](images/de/06a-compteurs.webp)

*Der freie Zähler, ohne Projekt nutzbar: du benennst ihn und wählst, ob er Zu-/Abnahmen oder Wiederholungen verfolgt.*

![Der Rechner](images/de/06b-calculateur.webp)

*Der Maschenrechner: Zu- oder Abnahmen über eine Reihenzahl verteilen oder herausfinden, wie viele Reihen du bei einem bestimmten Rhythmus brauchst — flach oder in Runden.*

Diese Werkzeuge funktionieren, ohne an ein bestimmtes Projekt gebunden
zu sein, erreichbar vom Start aus:
- **Maschenrechner**: er rechnet in beide Richtungen. Entweder gibst du ihm
  eine Reihenzahl, und er sagt dir, wie du deine Zu- oder Abnahmen darauf
  verteilst; oder du gibst ihm deinen Rhythmus („alle 4 Reihen“), und er sagt
  dir, wie viele Reihen du bis zu deiner Zielmaschenzahl brauchst und auf
  welche Reihe die letzte Änderung fällt. Ein Feld gibt an, wie viele Maschen
  du jedes Mal zu- oder abnimmst — meistens 1, bei einem Ärmel 2, wo du auf
  jeder Seite eine Masche zunimmst. Lässt sich dein Ziel nicht genau erreichen,
  schlägt er dir die beiden Möglichkeiten davor und danach vor, statt still zu
  runden. Flach spricht er von Reihen, in Runden von Runden.
- **Freier Zähler**: ein oder mehrere unabhängige Zähler (+/−, ein zu
  erreichendes Ziel, Zurücksetzen), für alles, was nicht zu einem
  gespeicherten Projekt gehört.
- **Deine eigene Nadel- (oder Häkelnadel-)größe finden**: Du gibst ein,
  was auf der Banderole deines Garnknäuels steht (empfohlene
  Nadelgröße und Maschenzahl für 10 × 10 cm oder 4 × 4 Zoll), danach
  die von der Anleitung verlangte Maschenprobe, und die App sagt dir,
  mit welcher Größe du beginnen solltest — eine Nummer größer, eine
  kleiner, oder dieselbe. Sie warnt dich auch, wenn der Unterschied zu
  groß ist, um ihn auszugleichen (dieses Garn passt nicht zu dieser
  Anleitung), und erinnert dich stets daran, dass dir eine Maschenprobe
  zur Kontrolle bleibt: ein Ausgangspunkt, keine Garantie. Das Feld für
  die Reihen ist optional.

## 7. Statistik

![Der Statistik-Bildschirm](images/de/07-statistiques.webp)

*Die verbrachte Zeit, nach Woche, Monat oder Jahr. Die laufende Summe beginnt jeden Montag wieder bei null; der Verlauf dagegen summiert sich auf.*

Die Zeit, die du mit Stricken oder Häkeln verbracht hast, nach Woche und
Monat, über alle Projekte hinweg — damit du deine eigene Regelmäßigkeit
erkennst (oder dich am zurückgelegten Weg erfreust).

## 8. Einstellungen

![Die Einstellungen](images/de/08-reglages.webp)

*Oben in den Einstellungen: Vorname, Standardtechnik, Erscheinungsbild, Sprache, Einheiten und Währung. Weiter unten liegen der Sicherungsordner und der Papierkorb.*

- **Profil**: dein Vorname (für die Begrüßung am Start) und deine
  Standardtechnik (Stricken oder Häkeln).
- **Erscheinungsbild**: helles Design, dunkles Design, oder passend zur
  Einstellung deines Smartphones.
- **Sprache**: Französisch, Englisch, Deutsch oder Spanisch. Jede
  Sprache erscheint in der Liste in ihrer eigenen Sprache geschrieben
  („Deutsch“, „Español“), damit du deine Sprache leicht wiederfindest.
- **Einheiten und Währung**:
  - **Metrisch** (Meter, Gramm) oder **imperial** (Yards, Unzen, Pfund)
    — alles folgt: die Eingabe deiner Knäuel, die Vorratssummen, die
    Maschenprobe (10 × 10 cm oder 4 × 4 Zoll). Wechselst du das System,
    ändert das keine gespeicherten Zahlen, es zeigt sie dir nur in der
    anderen Einheit erneut an.
  - **Währung** aus fünf Möglichkeiten (€, $, £, CHF, CA$). Beachte: Es
    handelt sich nur um eine Beschriftung — bereits eingegebene Preise
    werden **nicht umgerechnet**, sondern nur mit dem anderen Symbol
    angezeigt — die App weist dich vor der Bestätigung darauf hin.
  - Beide Einstellungen werden dir **schon auf dem ersten Bildschirm**
    beim Öffnen der App angeboten, vorausgefüllt nach der Sprache
    deines Smartphones; du kannst sie hier jederzeit ändern.
- **Daten**:
  - Export deines Vorrats, deiner Projekte oder Anleitungen als Tabelle
    (CSV), um sie andernorts anzusehen oder zu sichern. Die Spalten
    folgen deinen aktuellen Einstellungen: Längen und Gewichte im
    gewählten Einheitensystem, Preise mit dem gewählten Währungssymbol.
  - Ein universeller **Papierkorb**: Jedes gelöschte Projekt, Garn oder
    jede gelöschte Anleitung landet dort und lässt sich jederzeit
    wiederherstellen (bis du ihn absichtlich leerst).
- **{app}-Ordner**: Du legst einen Ordner auf deinem Smartphone (oder
  einen synchronisierten Ordner) fest, in den die App **fortlaufend
  alles sichert**, was du tust, als lesbare Dateien — du musst nicht auf
  „Speichern“ tippen. Installierst du die App neu und wählst denselben
  Ordner erneut aus, kehrt alles wie zuvor zurück.
- **Mitwirken**: ein Link zum Quellcode (die App ist quelloffen) und zu
  Möglichkeiten, sie zu unterstützen.

## 9. Unter der Haube — was {app} dir garantiert

- **Standardmäßig offline**: Keine deiner Daten verlässt jemals dein
  Smartphone, außer dem Sicherungsordner, den **du selbst wählst**.
- **Kein Konto, keine Bezahlschranke**: Alle oben genannten Funktionen
  sind kostenlos, ohne gesperrte Kernfunktion.
- **Nichts geht aus Versehen verloren**: Jedes Löschen kannst du sofort
  rückgängig machen, und es landet ohnehin im Papierkorb.
- **Für alle lesbar gestaltet**: ausreichende Kontraste, groß genug zum
  leichten Antippen geratene Schaltflächen, kompatibel mit
  Bildschirmlesern.
- **Auf jedem Bildschirm angenehm**: Auf einem kleinen Smartphone läuft
  nichts über oder wird abgeschnitten; auf einem Tablet nutzt die App
  den zusätzlichen Platz — deine Projekt- und Anleitungslisten
  verteilen sich auf mehrere Spalten statt eines einzigen langen
  Stapels, und der Reader kann das Diagramm neben dem Text behalten.
  Die App berücksichtigt die reservierten Bereiche deines Bildschirms
  (Statusleiste, Notch, Navigationsleiste): Inhalte schieben sich nicht
  mehr darunter.
- **In vier Sprachen**: Französisch, Englisch, Deutsch und Spanisch.
