# {app} Guide

## The spirit of {app}

![Welcome screen of {app}](images/en/00-bienvenue.webp)

*The very first launch: first name, craft, language and theme.*

{app} helps you keep all your knitting and crochet projects in one
place: your yarn, your patterns adjusted to your size, and your
progress. It's **free, open-source and works offline** — your data
stays on your phone, not on a server. Nothing is ever lost by mistake:
everything you delete ends up in a trash bin.

## 1. Home — your dashboard

![The {app} home screen](images/en/01-accueil.webp)

*Home: the "Resume" tile jumps back to the last project you worked on, the two counters summarise the essentials, and the three tools are within thumb's reach.*

Opening the app, you'll find:
- **Your last project**, with a **Resume** button to pick up exactly
  where you left off. It really is the last project you **actually
  knitted or crocheted on** (your last session), not just the last one
  you edited — and it shows you the current row.
- A **summary**: how many projects you have in progress, the time
  you've spent knitting or crocheting this week (with details in
  **Statistics**), and your **money spent** — the total of everything
  you've paid for yarn since you started using the app, in the
  currency you chose. This figure never goes down by itself: using up
  a skein or finishing a project doesn't lower it (only a new purchase
  raises it); it can only go down if you delete or correct a purchase
  line yourself in the "Purchases and gifts" block of a yarn's page
  (point 5). (If you've used more than one currency, each keeps its
  own total: the app never mixes them, since it has no exchange rate
  to rely on.) Tapping this figure opens the **Expenses** screen,
  described in point 5. This tile doesn't appear until you've recorded
  at least one purchase (for example on a brand-new install).
- This figure is different from your **stash value**, shown in the
  **Yarn stash** screen (point 5): that one tracks what's currently on
  your shelves and drops when you use a skein. The two figures live
  side by side on purpose: one tells you what you've spent, the other
  what you have left.
- All your projects, **grouped by status** (in progress, to do, on
  hold, finished, abandoned), with a button to show them all or
  collapse the list.
- Quick access to the **tools** (stitch calculator, free counter,
  needle/hook helper) and the **+ Create a project** button.

## 2. Your projects — the heart of the app

![A project's page, Sections tab](images/en/02-fiche-projet.webp)

*A project's page: overall progress, the "Follow the pattern" button, then one tile per section with its own progress and its "done" checkbox.*

### Create, edit, delete

Creating a project takes a few seconds: name, craft (knitting or
crochet), linked pattern (or "Free-form pattern" if you're not using
one). Choose an existing pattern and the app **pre-fills** sizes,
needles or hook, gauge and type for you — you just need to adjust from
there. A deleted project is **never lost right away**: you can still
undo it immediately after, or restore it later from the trash
(Settings).

### The project page, in tabs

- **Sections**: the stages of your piece (front, back, sleeve…), each
  with a status badge (to do / started / in progress / finished) and,
  when the pattern has a chart, a preview of the matching diagram.
- **Details**: all the project's information — craft, sizes, needles
  or hook, gauge, start/end dates, your star rating and a personal
  note.
- **Gallery**: your project photos, plus the pattern's original photos
  below them. You choose which one to use as the **cover photo** (by
  default, the pattern's first photo).
- **Sessions**: the history of your knitting/crochet sessions, with the
  length of each one, and the option to add a
  session manually (for time you spent without the app open).

### Working live — a session

Open a section to knit or crochet and you'll find:
- A **timer** waiting at the bottom of the screen. It **doesn't start
  on its own**: you tap it to start it, and tap it again to pause for
  an interruption (the button then shows **Resume** with the time
  already counted). Once started, it keeps running even if you turn
  off the screen, open another app, or restart your phone — it always
  picks the thread back up for you.
- You **check off rows** one by one, with the instructions shown (up
  to 8 lines visible, automatically resuming right where you left
  off).
- Several **counters** per project (stitches, rows, repeats…), each
  with a + and − button and a way to correct a mistaken tap.
- A **Close and save** button neatly archives your session in the
  Sessions tab.

## 3. The pattern that adapts to you — the interactive reader

![The reader: size picker and cheat sheet](images/en/03a-lecteur-haut.webp)

*Top of the reader: you pick your size once, and the cheat sheet (materials, size table, techniques, abbreviations) stays within reach.*

![The reader: chart followed row by row](images/en/03b-lecteur-diagramme.webp)

*Further down: you follow the chart row by row, with its own "Chart row" counter, its reading direction, and the timer at the bottom of the screen.*

This is {app}'s flagship feature. Once a pattern has been put into
"guided reading" format (the 3 sample patterns already are, as is any
imported and checked pattern), it gives you:

- **The size picker**: pick your size once, and **every number in the
  pattern filters itself automatically** for you (stitches, rows,
  lengths). No more decoding notations like "104 (108) 112…" line
  after line.
- **Step-by-step tracking**: check off each step, with an overall and
  per-section progress bar, and built-in repeat counters
  ("− 3/12 +") that disappear on their own if they don't apply to your
  chosen size.
- **The interactive chart**: the pattern's diagram (lifted straight
  from the original PDF) with a **band that follows your current
  row**, rows already done shown greyed out, and a "Row X of 52"
  counter. Reachable directly on the page or through a floating
  button, with its state shared across every section using the same
  chart.
- **The cheat sheet**: the pattern's abbreviations pop up as a tooltip
  as soon as you tap them, without leaving your current row; a full
  panel also groups the techniques (with video tutorials), materials
  and gauge, the size table, the list of abbreviations, and the
  **tips and tricks** given by the pattern.
- You can read a pattern (previewed from the library) **or** follow
  your real progress from a project — both paths exist, and your
  progress is always saved.

### The full-screen chart, and how to align it well

This is the most technical operation in the app, so here's the detail.

Tap a chart (or the "expand" button next to it) and it opens full
screen: you can then zoom (pinch with two fingers, double-tap, or +/−
buttons) and pan around to read every stitch, with the same
row-tracking buttons as on the page.

The problem alignment solves: the original PDF often has margins
(text, white space) around the chart's grid. Without a setting, the
app doesn't know where the grid starts and ends on the image — the
band showing you "here's where you are" could land in the wrong spot.

![Aligning a chart](images/en/03c-diagramme-calage.webp)

*Alignment mode: the two arrow handles you drag onto the edges of the grid, the instruction, and the three buttons Reset / Cancel / Save.*

**How to align a chart, the first time you open it:**

1. Full screen, in the top bar, tap the **Align** icon (two horizontal
   bars linked by a vertical arrow) — the first icon after the title,
   right before the zoom and close buttons; this button carries no
   text, only that pictogram.
2. Two arrow handles appear on the image, each with a small label
   ("Top of the grid" / "Bottom of the grid"). Drag each one onto
   **exactly the edge of the grid**: the "Bottom of the grid" line
   onto the very **first row** of the chart, the "Top of the grid" one
   onto the very **last**. (Not onto the surrounding text or margins,
   nor onto the edge of the photo itself — onto the grid alone.)
3. While you adjust, a guide band stays visible on your current row:
   use it to check live that things line up, before you confirm.
4. Tap **Save** to finish. ("Cancel" abandons the adjustment in
   progress; "Reset" removes any existing alignment and you start over
   from the full image.)

Once aligned, row tracking stays accurate for the rest of your piece on
that chart, within **that project**. Worth noting: the alignment is
saved together with your progress on the project, not with the
pattern itself — so if you start a second project from the same
pattern, you'll need to do it again once for the new project (the
operation only takes a few seconds).

**Keeping track of your position on a long row.**

![The progress handle on the current row](images/en/03d-diagramme-rideau.webp)

*The round handle, sitting on the current row: to its right, the part of the row already done is tinted. It only exists on that one row.*

On a very wide chart, once you've zoomed in, it's easy to lose track of
which stitch you're on. Full screen, a **small round handle** appears
on the current row — and on that row alone, not the whole chart. Drag
it left to right (or the other way) following your stitches: the
portion of the row it leaves behind gets tinted, standing for what
you've already knitted.

A button next to the row counter flips the tinted side (useful when
the next row reads in the other direction). The handle returns to its
own place at each new row, and its position is kept even after you
leave the app. The first time you open a chart, a small message points
out that it's there, so you don't miss it.

### On tablets: the chart next to the text

Knit on a tablet held sideways and the reader switches on its own to
**two columns**: your instructions on the left, a chart displayed
permanently on the right — no more scrolling back and forth between
the two. You keep control:

- On any other chart in the pattern, the **Show on the right** button
  moves it into the side panel (handy when a pattern contains
  several).
- The **Move back into the text** button closes the panel and puts the
  chart back in its place in the flow, if you'd rather read everything
  in a single column.
- At the spot in the text where the chart used to sit, a note reminds
  you that it's **shown on the right** — nothing disappears without
  telling you.

This setting only lasts for your current session: reopening the
pattern brings back the panel with the first chart. On a phone (or a
tablet held upright), the reader stays in a single column, as before.
A pattern with no chart has no side panel at all.

## 4. Your pattern library

![The pattern library](images/en/04-bibliotheque.webp)

*The library, with the three sample patterns provided on first launch.*

![A pattern's page](images/en/04b-fiche-patron.webp)

*A pattern's page, deliberately spare: create a project, or preview. (Correcting the import is reached from the preview.)*

- **Import a PDF**: drop your pattern's PDF, and the app reads it and
  **automatically rebuilds** the sizes, rows and sections for you —
  for free, with no internet connection and nothing sent anywhere. A
  review screen lets you check and correct the result before saving
  it.
- **Find a pattern**: category chips at the top of the library show
  you **how many patterns** each one holds, for an instant sense of
  where to look.
- **Correct a pattern**: a full-screen editor lets you touch up an
  imported pattern (text, sizes, images) if the automatic import
  didn't get everything right. This is the app's other technical
  operation — detailed below.
- **Pattern view**: simple reading for patterns without special
  formatting, or patterns you've typed in entirely by hand.
- **3 sample patterns** ship with the app from the very first launch,
  so you can explore every feature without importing anything.

### The correction editor, in detail

This is the most technical operation in the app alongside chart
alignment (above): here's how it really works.

**The principle.** A pattern is made of lines of text, and **each line
carries a category** that tells the app what it's for: a checkbox
during knitting? a section title? a plain reference note? Automatic
import already assigns a category to every line as it comes in — the
editor lets you correct the ones it guessed wrong, and fix the text if
a sentence got cut awkwardly.

**The possible categories:**

| Category | What it becomes in your project |
|---|---|
| **Step** | A checkbox during knitting or crochet — the heart of step-by-step tracking. |
| **Counter** | A repeated step, with its own counter. Two variants: **Repeat** (redo the line N times) and **Cadence** (redo the line every X rows, N times). |
| **Note** | Informative text shown at that spot, with no checkbox. |
| **Section** | A section title (Front, Sleeve, Collar…), with its automatic icon — this is what splits your pattern into the Sections tab. |
| **Reference** | Information from the pattern's page (yarn, needles, sizes…) — **not** step-by-step tracking. Seven sub-categories: **Yarn** (brand, fibre, yardage, quantities), **Needles** (needles or hooks), **Gauge** (the reference measurement, e.g. "10 × 10 cm = 22 stitches"), **Materials** (everything else: buttons, markers…), **Abbreviations** (one per line), **Sizes** (the table of finished measurements — not the per-size instructions, which are Sections), **Techniques** (a technique explained). These are the blocks that fill the interactive reader's cheat sheet (section 3 above). |
| **Text** | A plain paragraph, with no particular role. |
| **Image** | A photo or a chart. |

**Changing a line's category:**

1. Put your cursor on the line (or select several lines at once). The
   toolbar just above the editor highlights the category already
   applied, so you always know where you stand.
2. Tap the button (Step, Note, Text) or pick from the menu (Counter,
   Section, Reference — those three have sub-categories) matching
   what you want the line to become.
3. The line's colour and rendering change right away to confirm.

**Two ways to view the text.** By default, the editor shows you a
**rich view**: images appear as thumbnails, counters as pills, rows
with their checkbox — a preview close to how it will actually look.
The **Edit text** button switches to raw text (the markup becomes
visible) and opens the keyboard: useful for fixing a wording, a typo,
or a sentence that the import cut awkwardly in two lines.

**Reordering without cut and paste.** Two arrows (up/down) move the
line where your cursor is, handy if the import placed a step or a
section title in the wrong spot.

**Turning a photo into a followable chart (or back again).** A
collapsible "Charts in this pattern" banner at the bottom of the
editor lists every section that contains an image. For each one, a
button switches between **Plain image** (just a photo) and **Follow
as a chart** (makes it followable row by row in the reader, with the
alignment described above) — handy if the import missed a chart, or
if you'd rather a plain photo stayed a plain photo.

**Saving.** The **Cancel** / **Save** buttons are fixed at the bottom
of the screen. Try to leave with unsaved changes and the app stops you
and asks for confirmation — nothing gets lost by mistake here either.

## 5. Your yarn stash

![The yarn stash](images/en/05-stock.webp)

*The stash: totals up top (skeins, length, weight, value), then one card per yarn with its status — free or reserved by a project.*

- **Add a skein**: brand, weight (with help understanding the weight
  categories), fibre content (picked from a list; if your fibre isn't
  listed, "Other" lets you type it in, and it's then offered like any
  other), colour (picked from a palette, with a custom shade picker if
  you need one), quantity, price, length and weight per skein, plus
  the purchase date and dye lot number.
  **As soon as you save it, the app immediately records the matching
  purchase**, and your money spent (point 1) goes up by the amount you
  entered. The date it suggests is today's: if you bought the yarn
  earlier, you can correct it directly in the form. (These two fields
  only appear when you create the entry. On an already-saved yarn
  page, the **Purchases and gifts** block takes over, with one line
  per acquisition.)
- **Yarn that isn't a single colour**: a **Colour type** field (solid,
  gradient, self-striping, speckled, hand-dyed) and a **Colourway
  description** field ("blue, green, yellow speckled with black")
  complete the colour swatch — because a single shade isn't enough to
  describe a multicoloured yarn. Colour type shows up in search and in
  the spreadsheet export.
- **The summary** at the top of the screen: number of skeins, total
  length and weight (switching on their own to km and kg once your
  totals get large), and your stash's total value.
- **Search and sort** your yarn by brand or weight, in a list or a
  visual grid.
- **Edit, duplicate or delete** an entry from its card's **Actions**
  menu (vertical three-dot icon). "Duplicate" is handy for the same
  yarn in a different colourway: everything carries over, you just
  need to change the colour.
- **The skein pool**: for each yarn, you can see at a glance how many
  skeins are **reserved** for a project and how many are **free**. You
  can't lower the quantity below what's already reserved (the app
  tells you how many skeins are held back); and it warns you if
  restoring a project from the trash puts your yarn reservations at
  risk — the project comes back regardless, but with a reduced
  reservation and a message explaining it to you.
- **A yarn's detail page**: a full summary (skeins, metres, projects
  using it), and a **Purchases and gifts** block that keeps a record
  of every acquisition of that yarn for you:
  - Each line carries a quantity, a price, a date and a dye lot, and
    states whether it was a **purchase** or a **gift** (a gift never
    counts towards your money spent). The three most recent lines are
    visible right away, the rest unfolds with a tap.
  - You can **add, edit or delete** a line at any time.
  - **Increase the quantity** of a yarn from its page and the app
    offers to record the matching purchase, dated today: you can
    accept it, mark it as a gift, or ignore it if you don't want to
    keep it. **Decreasing a quantity, however, never touches your
    money spent** — only an increase can create a purchase.
  - If the number of skeins on the page doesn't match what the
    history recorded (for example after you manually corrected the
    stash), an alert points it out and a **Fix** button offers you two
    solutions: add the missing purchase, or adjust the displayed
    quantity.
  - A purchase keeps its label even after you permanently delete the
    yarn's page: nothing you've spent disappears, it stays visible in
    the **Expenses** screen.

### The Expenses screen

Reached by tapping the money spent on Home (point 1), this screen
summarises everything you've paid for yarn:
- The **total spent**, by currency if you've used more than one.
- A **filter by year**: a **Year** menu at the top of the screen shows
  only the year you choose (or "All years"), and totals recalculate
  accordingly. Purchases you haven't dated end up under "Unknown
  date", which is added to the menu whenever there are any.
- A **breakdown by year then by month**, to see where your money goes
  over time.
- The **full list** of every purchase and gift, including those whose
  yarn page you've since deleted (marked "Deleted yarn").
- The option to **delete** a line directly from this screen, with a
  chance to **undo** right after in case of a mistake.

## 6. Standalone tools

![The free counter](images/en/06a-compteurs.webp)

*The free counter, usable without a project: name it, and choose whether it tracks increases/decreases or repeats.*

![The calculator](images/en/06b-calculateur.webp)

*The stitch calculator: spreading increases or decreases over a number of rows, or working out how many rows you need at a given rate — flat or in the round.*

These tools work without being tied to a specific project, reachable
from Home:
- **Stitch calculator**: it answers both ways round. Either you give it a
  number of rows and it tells you how to spread your increases or decreases
  over them; or you give it your rate ("every 4 rows") and it tells you how
  many rows you need to reach your target stitch count, and which row the last
  change falls on. One field says how many stitches you add or remove each
  time — usually 1, or 2 for a sleeve where you increase one stitch on each
  side. When your target can't be reached exactly, it offers the two options
  either side of it rather than rounding silently. Flat it talks in rows, in
  the round in rounds.
- **Free counter**: one or more independent counters (+/−, a target to
  reach, reset), for anything that isn't part of a saved project.
- **Find my needle (or hook) size**: enter what's written on your
  skein label (recommended needle size and stitch count for
  10 × 10 cm, or 4 × 4 inches) then the gauge your pattern asks for,
  and the app tells you which size to start with — one size up, one
  down, or the same. It also warns you when the gap is too large to
  make up (this yarn won't work with this pattern), and always
  reminds you that a swatch still needs knitting to check: it's a
  starting point, not a guarantee. The rows field is optional.

## 7. Statistics

![The statistics screen](images/en/07-statistiques.webp)

*Time spent, by week, month or year. The running total starts back at zero every Monday; the history, on the other hand, accumulates.*

The time you've spent knitting or crocheting, by week and by month,
across every project — a way to notice your own consistency (or enjoy
seeing how far you've come).

## 8. Settings

![Settings](images/en/08-reglages.webp)

*Top of Settings: first name, default craft, theme, language, units and currency. Further down are the backup folder and the trash.*

- **Profile**: your first name (used for the Home greeting) and your
  default craft (knitting or crochet).
- **Appearance**: light theme, dark theme, or matching your phone's
  own setting.
- **Language**: French, English, German or Spanish. Each language is
  written in its own language in the list ("Deutsch", "Español"), so
  you find your own language easily.
- **Units and currency**:
  - **Metric** (metres, grams) or **imperial** (yards, ounces, pounds)
    — everything follows: entering your skeins, stash totals, gauge
    (10 × 10 cm or 4 × 4 inches). Switching systems doesn't change any
    of your saved numbers, it just redisplays them in the other unit.
  - **Currency** among five (€, $, £, CHF, CA$). Note that it's a
    plain label: prices you've already entered **aren't converted**,
    they're displayed with the other symbol — the app warns you about
    this before confirming.
  - Both settings are offered to you **right from the first screen**
    when you open the app, pre-filled from your phone's language; you
    can change them here at any time.
- **Data**:
  - Export your stash, projects or patterns to a spreadsheet (CSV), to
    view or back them up elsewhere. Columns follow your current
    settings: lengths and weights in your chosen unit system, prices
    with your chosen currency symbol.
  - A universal **Trash**: any project, yarn or pattern you delete
    ends up there and can be restored at any time (until you empty it
    on purpose).
- **{app} folder**: choose a folder on your phone (or a synced folder),
  and the app **continuously backs up** everything you do into it, as
  readable files — no need to tap "Save". Reinstall the app and choose
  the same folder again, and everything comes back as it was.
- **Contribute**: a link to the source code (the app is open source)
  and to ways of supporting it.

## 9. Under the hood — what {app} guarantees you

- **Offline by default**: none of your data ever leaves your phone,
  except the backup folder **you choose yourself**.
- **No account, no paywall**: every feature above is free, with no
  core feature locked away.
- **Nothing is lost by mistake**: every deletion can be undone
  instantly, and ends up in the trash regardless.
- **Designed to be readable by everyone**: sufficient contrast, buttons
  large enough to tap easily, compatible with screen readers.
- **Comfortable on every screen**: on a small phone, nothing overflows
  or gets cut off; on a tablet, the app makes use of the extra space —
  your lists of projects and patterns spread across several columns
  instead of one long stack, and the reader can keep the chart next
  to the text. The app accounts for your screen's reserved areas
  (status bar, notch, navigation bar): content no longer slides
  underneath them.
- **In four languages**: French, English, German and Spanish.
